<?php ob_start();                     ?>
<?php session_start();                ?>
<?php include "data/condata.php";     ?>

<?php
   if(!$_SESSION['LOGIN'])
   {
      header("Location:login.php");
   }
   
   $intSize            = 10;
   $intLength          = 10;
   $intReference       = $_GET['pg'];
   $intComboBox        = $_GET['cmb'];
   $strTextBox         = $_GET['txt'];
   $strObject          = "pg=$intReference%cmb=$intComboBox%txt=$strTextBox";
   
   if($_POST)
   {
      header("Location:lookup_account.php?pg=1&cmb=". $_POST['00'] ."&txt=". $_POST['01']);
   }
   
   if(!is_numeric($intReference) || $intReference < 1)
   {
      $intReference    = 1;
   }
   
   switch($intComboBox)
   {
      case 0           : $strFilter  = $strTextBox !=  "" ? "WHERE (User_Reference   LIKE '%$strTextBox%')" : "";
                         break;
      case 1           : $strFilter  = $strTextBox !=  "" ? "WHERE (User_Description LIKE '%$strTextBox%')" : "";
                         break;
   }
   
   $intRecord          = ($intReference - 1) * $intSize;
   
   $qrData             = "SELECT * FROM Ms_User $strFilter ORDER BY User_Reference LIMIT $intRecord, $intSize";
   $rsData             = mysql_query($qrData);
   
   $qrCount            = "SELECT * FROM Ms_User $strFilter ORDER BY User_Reference";
   $rsCount            = mysql_query($qrCount);
   
   $intCount           = 0;
   
   while($arrFields    = mysql_fetch_array($rsData))
   {
      $arrData[$intCount][0] = stripslashes($arrFields[0]);
      $arrData[$intCount][1] = stripslashes($arrFields[1]);
      
      $intCount++;
   }
   
   if(mysql_num_rows($rsCount) > 0)
   {
      $intRecord       = ceil(mysql_num_rows($rsCount) / $intSize);
   } else {
      $intRecord       = 1;
   }
   
   If($intReference    < 1)
   {
      $intReference    = 1;
   } else {
      If($intReference > $intRecord)
      {
         $intReference = $intRecord;
      }
   }
   
   if($intReference   <= $intLength)
   {
      $intPage_1       = 1;
      $intPage_2       = $intLength;
   } else {
      $intCount        = 0;
      $intParent       = $intLength;
      
      while($intReference > $intParent)
      {
         $intParent    = $intParent  + $intLength;
         $intCount++;
      }
      
      $intPage_1       = ($intCount  * $intLength) + 1;
      $intPage_2       = ($intPage_1 + $intLength) - 1;
   }
   
   if($intPage_2       > $intRecord)
   {
      $intPage_2       = $intRecord;
   }
?>

<html>

<head>
   <meta http-equiv="Content-Language" content="en-us">
   <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
   <meta name="Keywords" content="Bursa Kerja, Career, Calon Karyawan, Cari Kerja, HRD, Human Resources, Indonesia, Interview, Jobs, Job Fair, Job Seeker, Karir, Kinerja, Lowongan, Outsources, Outsourcing, Recruitments, Relasi, Relationships, Resources, SDM, Sumber Daya Manusia, Tenaga Kerja, Wawancara">
   <meta name="Description" content="Indonesia's Best Outsourcing">
   <meta name="Author" content="Exteron Corporation">
   <title>..:: PT Jasmine Indonesia ::..</title>
   <link href="style.css" type="text/css" rel="stylesheet">
</head>

<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" background="images/back_01.gif">
   <table cellpadding="0" cellspacing="0" border="0" width="100%">
   <tr>
      <td width="100%" background="images/back_01.gif">
         <div align="center"><center>
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <tr>
            <td width="750" height="100" background="images/logo.gif"></td>
         </tr>
         <tr>
            <td width="750">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width="125" height=" 25" background="images/main_01.gif">
                     <p class="main" align="center">
                        <?php
                           if($_SESSION['PERMISSION_01'])
                           {
                              echo "<a class=\"main\" href=\"lookup_registrar.php\">JOB SEEKER</a>";
                           } else {
                              echo "<b>JOB SEEKER</b>";
                           }
                        ?>
                     </p>
                  </td>
                  <td width="125" height=" 25" background="images/main_02.gif">
                     <p class="main" align="center">
                        <?php
                           if($_SESSION['PERMISSION_02'])
                           {
                              echo "<a class=\"main\" href=\"lookup_interview.php\">INTERVIEW</a>";
                           } else {
                              echo "<b>INTERVIEW</b>";
                           }
                        ?>
                     </p>
                  </td>
                  <td width="125" height=" 25" background="images/main_02.gif">
                     <p class="main" align="center">
                        <?php
                           if($_SESSION['PERMISSION_03'])
                           {
                              echo "<a class=\"main\" href=\"lookup_resources.php\">EMPLOYEE</a>";
                           } else {
                              echo "<b>EMPLOYEE</b>";
                           }
                        ?>
                     </p>
                  </td>
                  <td width="125" height=" 25" background="images/main_02.gif">
                     <p class="main" align="center">
                        <?php
                           if($_SESSION['PERMISSION_04'])
                           {
                              echo "<a class=\"main\" href=\"lookup_reports.php\">REPORTS</a>";
                           } else {
                              echo "<b>REPORTS</b>";
                           }
                        ?>
                     </p>
                  </td>
                  <td width="125" height=" 25" background="images/main_12.gif">
                     <p class="main" align="center">
                        <b>USER ACCOUNT</b>
                     </p>
                  </td>
                  <td width="125" height=" 25" background="images/main_03.gif">
                     <p class="main" align="center">
                        <a class="main" href="logout.php">LOGOUT</a>
                     </p>
                  </td>
               </tr>
               </table>
            </td>
         </tr>
         </table>
         </center></div>
      </td>
   </tr>
   <tr>
      <td width="100%" background="images/back_02.gif">
         <div align="center"><center>
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <tr>
            <td width="750" background="images/back_04.gif">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <form name="form" method="post">
                     <tr>
                        <td width="750">
                           <p align="center">
                              <select class="form" size="1" name="00">
                                 <option value="0" <?php echo $intComboBox == 0 ? "selected" : ""; ?>>Nama Pengguna</option>
                                 <option value="1" <?php echo $intComboBox == 1 ? "selected" : ""; ?>>Keterangan</option>
                              </select>
                             �<input class="form" type="text" name="01" size="50" value="<?php echo $strTextBox; ?>">
                             �<input type="image" name="02" src="images/button_03.gif" width="90" height="30" align="absmiddle">
                           </p>
                        </td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <tr>
                        <td width="100">
                           <p align="left">
                              <a href="detail_account.php?ref=&obj=<?php echo $strObject ; ?>"><img
                              src="images/button_01.gif" width="90" height="30" border="0"></a>
                           </p>
                        </td>
                        <td width="650"></td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 10"></td>
               </tr>
               <tr>
                  <td width="750" height=" 30" background="images/menu_03.gif">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <tr>
                        <td width="150"><p class="menu" align="center">Nama Pengguna</p></td>
                        <td width="550"><p class="menu" align="center">Keterangan</p></td>
                        <td width=" 50"><p class="menu" align="center">...</p></td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <?php
                        for($intCount = 0; $intCount < mysql_num_rows($rsData); $intCount++)
                        {
                     ?>
                     <tr>
                        <td width="750" height=" 10"></td>
                     </tr>
                     <tr>
                        <td width="750">
                           <table cellpadding="0" cellspacing="0" border="0" width="750">
                           <tr>
                              <td width="  5"></td>
                              <td width="140">
                                 <p align="center">
                                    <?php
                                       echo "<a href=\"detail_account.php?ref=". $arrData[$intCount][0] ."&obj=$strObject\">";
                                       echo $arrData[$intCount][0];
                                       echo "</a>";
                                    ?>
                                 </p>
                              </td>
                              <td width=" 10"></td>
                              <td width="540">
                                 <p align="left"><?php echo $arrData[$intCount][1]; ?></p>
                              </td>
                              <td width=" 10"></td>
                              <td width=" 40">
                                 <p align="center">
                                    <?php
                                       if($_SESSION['LEVEL'])
                                       {
                                          echo "<a href=\"delete_account.php?ref=". $arrData[$intCount][0] ."&obj=$strObject\">";
                                          echo "<img src=\"images/button_02.gif\" width=\"30\" height=\"30\" border=\"0\">";
                                          echo "</a>";
                                       } else {
                                          echo "<img src=\"images/button_02.gif\" width=\"30\" height=\"30\" border=\"0\">";
                                       }
                                    ?>
                                 </p>
                              </td>
                              <td width="  5"></td>
                           </tr>
                           </table>
                        </td>
                     </tr>
                     <tr>
                        <td width="750" height=" 10"></td>
                     </tr>
                     <tr>
                        <td width="750" height="  1" background="images/spacer_01.gif"></td>
                     </tr>
                     <?php
                        }
                     ?>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750">
                     <p class="main" align="center">
                        <?php
                           if(mysql_num_rows($rsData) > 0)
                           {
                              if($intPage_1    > $intLength)
                              {
                                 echo "<a href=\"lookup_account.php?pg=". ($intPage_1 - 1) ."&cmb=$intComboBox&txt=$strTextBox\">";
                                 echo "...";
                                 echo "</a>";
                                 echo "�����";
                              }
                              
                              for($intCount    = $intPage_1; $intCount <= $intPage_2; $intCount++)
                              {
                                 if($intCount  > $intPage_1)
                                 {
                                    echo "�����";
                                 }
                                 
                                 if($intCount == $intReference)
                                 {
                                    echo "<b>$intCount</b>";
                                 } else {
                                    echo "<a href=\"lookup_account.php?pg=". $intCount     ."&cmb=$intComboBox&txt=$strTextBox\">";
                                    echo $intCount;
                                    echo "</a>";
                                 }
                              }
                              
                              if($intPage_2    < $intRecord)
                              {
                                 echo "�����";
                                 echo "<a href=\"lookup_account.php?pg=". ($intPage_2 + 1) ."&cmb=$intComboBox&txt=$strTextBox\">";
                                 echo "...";
                                 echo "</a>";
                              }
                           }
                        ?>
                     </p>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               </table>
            </td>
         </tr>
         </table>
         </center></div>
      </td>
   </tr>
   <tr>
      <td width="100%" background="images/back_01.gif">
         <div align="center"><center>
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <tr>
            <td width="750" background="images/back_03.gif">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750">
                     <p class="foot" align="right">
                        <a class="foot" </a> � 2013 Untuk Skripsi
                     </p>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               </table>
            </td>
         </tr>
         </table>
         </center></div>
      </td>
   </tr>
   </table>
</body>

</html>