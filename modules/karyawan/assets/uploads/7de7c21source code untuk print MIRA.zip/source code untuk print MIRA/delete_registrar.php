<?php ob_start();                     ?>
<?php session_start();                ?>
<?php include "data/condata.php";     ?>
<?php include "modules/function.php"; ?>

<?php
   if(!$_SESSION['LOGIN'])
   {
      header("Location:login.php");
   }
   
   $strReference       = $_GET['ref'];
   $strObject          = str_replace("%", "&", $_GET['obj']);
   
   $qrDelete           = "DELETE FROM Ms_Card ".
                         "WHERE (Card_Reference = '$strReference') AND (Card_Type = 'RG') AND (Card_Reference NOT IN (SELECT Interview_Card FROM Ms_Interview)) ".
                         "ORDER BY Card_Reference";
   
   $rsDelete           = mysql_query($qrDelete);
   
   header("Location:lookup_registrar.php?$strObject");
?>