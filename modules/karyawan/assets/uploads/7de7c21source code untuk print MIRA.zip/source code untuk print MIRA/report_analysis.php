<?php ob_start();                     ?>
<?php session_start();                ?>
<?php include "data/condata.php";     ?>
<?php include "modules/function.php"; ?>

<?php
   if(!$_SESSION['LOGIN'])
   {
      header("Location:login.php");
   }
   
   $arrForm[0]         = $_GET['02'] ."-". $_GET['01'] ."-". $_GET['00'] ." 00:00:00";
   $arrForm[1]         = $_GET['05'] ."-". $_GET['04'] ."-". $_GET['03'] ." 00:00:00";
   $arrForm[2]         = $_GET['06'];
   $arrForm[3]         = $_GET['07'];
   
   $intTotal[0]        = 0;
   $intTotal[1]        = 0;
?>

<html>

<head>
   <meta http-equiv="Content-Language" content="en-us">
   <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
   <meta name="Keywords" content="Bursa Kerja, Career, Calon Karyawan, Cari Kerja, HRD, Human Resources, Indonesia, Interview, Jobs, Job Fair, Job Seeker, Karir, Kinerja, Lowongan, Outsources, Outsourcing, Recruitments, Relasi, Relationships, Resources, SDM, Sumber Daya Manusia, Tenaga Kerja, Wawancara">
   <meta name="Description" content="Indonesia's Best Outsourcing">
   <meta name="Author" content="Exteron Corporation">
   <title>..:: PT Jasmine Indonesia ::..</title>
   <link href="style.css" type="text/css" rel="stylesheet">
</head>

<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0">
   <div align="center"><center>
   <table cellpadding="0" cellspacing="0" border="0" width="750">
   <tr>
      <td width="750" height=" 20"></td>
   </tr>
   <tr>
      <td width="750"><p class="head" align="center"><b>JASMINE INDONESIA PT</b></p></td>
   </tr>
   <tr>
      <td width="750">
         <p class="prnt" align="center">
            <?php
               switch($arrForm[3])
               {
                  case "SM" : echo "<b>Analisa Wawancara Kerja (Ringkasan)</b>";
                              break;
                  case "DT" : echo "<b>Analisa Wawancara Kerja (Rincian)</b>";
                              break;
               }
            ?>
         </p>
      </td>
   </tr>
   <tr>
      <td width="750" height=" 50"></td>
   </tr>
   <tr>
      <td width="750" height="  1" background="images/spacer_01.gif""></td>
   </tr>
   <tr>
      <td width="750" height=" 10"></td>
   </tr>
   <tr>
      <td width="750">
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <?php
            if($arrForm[3] == "DT")
            {
         ?>
         <tr>
            <td width="  5"></td>
            <td width=" 90"><p class="prnt" align="left"><b>No. Dokumen</b></p></td>
            <td width=" 10"></td>
            <td width="190"><p class="prnt" align="left"><b>Nama Lengkap</b></p></td>
            <td width=" 10"></td>
            <td width=" 40"><p class="prnt" align="right"><b>Usia</b></p></td>
            <td width=" 10"></td>
            <td width="140"><p class="prnt" align="left"><b>Kota</b></p></td>
            <td width=" 10"></td>
            <td width=" 90"><p class="prnt" align="left"><b>No. Telp</b></p></td>
            <td width=" 10"></td>
            <td width=" 90"><p class="prnt" align="left"><b>No. Ponsel</b></p></td>
            <td width=" 10"></td>
            <td width=" 40"><p class="prnt" align="right"><b>IPK</b></p></td>
            <td width="  5"></td>
         </tr>
         <?php
            } else {
         ?>
         <tr>
            <td width="  5"></td>
            <td width="540"><p class="prnt" align="left"><b>Klien</b></p></td>
            <td width=" 10"></td>
            <td width=" 90"><p class="prnt" align="right"><b>Total Kantor</b></p></td>
            <td width=" 10"></td>
            <td width=" 90"><p class="prnt" align="right"><b>Total Klien</b></p></td>
            <td width="  5"></td>
         </tr>
         <?php
            }
         ?>
         </table>
      </td>
   </tr>
   <tr>
      <td width="750" height=" 10"></td>
   </tr>
   <tr>
      <td width="750" height="  1" background="images/spacer_01.gif"></td>
   </tr>
   <tr>
      <td width="750" height=" 10"></td>
   </tr>
   <tr>
      <td width="750">
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <?php
            for($intCount       = 0; $intCount < count($arrForm); $intCount++)
            {
               switch($intCount)
               {
                  case 2        : $strFilter .= $arrForm[2] != "" ? "AND (Ms_Interview.Interview_Company = '$arrForm[2]')" : "";
                                  break;
               }
            }
            
            for($dateCount      = date_create($arrForm[0]); $dateCount <= date_create($arrForm[1]); date_add($dateCount, new DateInterval('P1D')))
            {
               switch($arrForm[3])
               {
                  case "SM"     : $qrData          = "SELECT Ms_Interview.Interview_Date_1, ".
                                                            "COUNT(Ms_Interview.Interview_Reference) AS Interview_Total ".
                                                     "FROM  (Ms_Card LEFT JOIN Ms_Interview ON Ms_Card.Card_Reference = Ms_Interview.Interview_Card) ".
                                                     "WHERE (ISNULL(Ms_Interview.Interview_Reference) = 0) ".
                                                            "AND (Ms_Interview.Interview_Date_1 = '". date_format($dateCount, "Y-m-d") ." 00:00:00') ".
                                                     "GROUP BY Ms_Interview.Interview_Date_1 ".
                                                     "ORDER BY Ms_Interview.Interview_Date_1";
                                  
                                  $rsData          = mysql_query($qrData);
                                  
                                  $intCount        = 0;
                                  
                                  while($arrFields = mysql_fetch_array($rsData))
                                  {
                                     $arrDate[0]            = explode(" ",  $arrFields[0]);
                                     $arrDate[0]            = explode("-", $arrDate[0][0]);
                                     
                                     $arrData[$intCount][0] = stripslashes($arrDate[0][2] ." ". $arrMonth[intval($arrDate[0][1])] ." ". $arrDate[0][0]);
                                     $arrData[$intCount][1] = stripslashes("Wawancara di Kantor");
                                     $arrData[$intCount][2] = stripslashes($arrFields[1]);
                                     
                                     $intCount++;
                                  }
                                  
                                  $qrData          = "SELECT Ms_Interview.Interview_Date_2, Ms_Interview.Interview_Company, ".
                                                            "COUNT(Ms_Interview.Interview_Reference) AS Interview_Total ".
                                                     "FROM  (Ms_Card LEFT JOIN Ms_Interview ON Ms_Card.Card_Reference = Ms_Interview.Interview_Card) ".
                                                     "WHERE (ISNULL(Ms_Interview.Interview_Reference) = 0) ".
                                                            "AND (Ms_Interview.Interview_Date_2 = '". date_format($dateCount, "Y-m-d") ." 00:00:00') $strFilter ".
                                                     "GROUP BY Ms_Interview.Interview_Date_2, Ms_Interview.Interview_Company ".
                                                     "ORDER BY Ms_Interview.Interview_Date_2, Ms_Interview.Interview_Company";
                                  
                                  $rsData          = mysql_query($qrData);
                                  
                                  while($arrFields = mysql_fetch_array($rsData))
                                  {
                                     $arrDate[0]            = explode(" ",  $arrFields[0]);
                                     $arrDate[0]            = explode("-", $arrDate[0][0]);
                                     
                                     $arrData[$intCount][0] = stripslashes($arrDate[0][2] ." ". $arrMonth[intval($arrDate[0][1])] ." ". $arrDate[0][0]);
                                     $arrData[$intCount][1] = stripslashes($arrFields[1]);
                                     $arrData[$intCount][2] = stripslashes($arrFields[2]);
                                     
                                     $intCount++;
                                  }
                                  
                                  break;
                  case "DT"     : $qrData          = "SELECT Ms_Card.*, Ms_Interview.*, ".
                                                            "YEAR(NOW()) - YEAR(Ms_Card.Card_Date) AS Card_Age ".
                                                     "FROM  (Ms_Card LEFT JOIN Ms_Interview ON Ms_Card.Card_Reference = Ms_Interview.Interview_Card) ".
                                                     "WHERE (ISNULL(Ms_Interview.Interview_Reference) = 0) ".
                                                            "AND (Ms_Interview.Interview_Date_1 = '". date_format($dateCount, "Y-m-d") ." 00:00:00') ".
                                                     "ORDER BY Ms_Interview.Interview_Date_1, Ms_Card.Card_Reference";
                                  
                                  $rsData          = mysql_query($qrData);
                                  
                                  $intCount        = 0;
                                  
                                  while($arrFields = mysql_fetch_array($rsData))
                                  {
                                     $arrDate[0]            = explode(" ", $arrFields[101]);
                                     $arrDate[0]            = explode("-", $arrDate[0][0]);
                                     
                                     $arrData[$intCount][0] = stripslashes($arrDate[0][2] ." ". $arrMonth[intval($arrDate[0][1])] ." ". $arrDate[0][0]);
                                     $arrData[$intCount][1] = stripslashes("Wawancara di Kantor");
                                     $arrData[$intCount][2] = stripslashes($arrFields[0]);
                                     $arrData[$intCount][3] = stripslashes($arrFields[2]);
                                     $arrData[$intCount][4] = stripslashes($arrFields[122]);
                                     $arrData[$intCount][5] = stripslashes($arrFields[12]);
                                     $arrData[$intCount][6] = stripslashes($arrFields[15]);
                                     $arrData[$intCount][7] = stripslashes($arrFields[16]);
                                     $arrData[$intCount][8] = stripslashes($arrFields[34]);
                                     
                                     $intCount++;
                                  }
                                  
                                  $qrData          = "SELECT Ms_Card.*, Ms_Interview.*, ".
                                                            "YEAR(NOW()) - YEAR(Ms_Card.Card_Date) AS Card_Age ".
                                                     "FROM  (Ms_Card LEFT JOIN Ms_Interview ON Ms_Card.Card_Reference = Ms_Interview.Interview_Card) ".
                                                     "WHERE (ISNULL(Ms_Interview.Interview_Reference) = 0) ".
                                                            "AND (Ms_Interview.Interview_Date_2 = '". date_format($dateCount, "Y-m-d") ." 00:00:00') $strFilter ".
                                                     "ORDER BY Ms_Interview.Interview_Date_2, Ms_Interview.Interview_Company, Ms_Card.Card_Reference";
                                  
                                  $rsData          = mysql_query($qrData);
                                  
                                  while($arrFields = mysql_fetch_array($rsData))
                                  {
                                     $arrDate[0]            = explode(" ", $arrFields[102]);
                                     $arrDate[0]            = explode("-", $arrDate[0][0]);
                                     
                                     $arrData[$intCount][0] = stripslashes($arrDate[0][2] ." ". $arrMonth[intval($arrDate[0][1])] ." ". $arrDate[0][0]);
                                     $arrData[$intCount][1] = stripslashes($arrFields[106]);
                                     $arrData[$intCount][2] = stripslashes($arrFields[0]);
                                     $arrData[$intCount][3] = stripslashes($arrFields[2]);
                                     $arrData[$intCount][4] = stripslashes($arrFields[122]);
                                     $arrData[$intCount][5] = stripslashes($arrFields[12]);
                                     $arrData[$intCount][6] = stripslashes($arrFields[15]);
                                     $arrData[$intCount][7] = stripslashes($arrFields[16]);
                                     $arrData[$intCount][8] = stripslashes($arrFields[34]);
                                     
                                     $intCount++;
                                  }
                                  
                                  break;
               }
               
               $intData         = $intCount;
               
               for($intCount    = 0; $intCount < $intData; $intCount++)
               {
                  if($arrForm[3] == "DT")
                  {
                     if($strReference    != $arrData[$intCount][0] || $strGroup != $arrData[$intCount][1])
                     {
                        if($strGroup     != "")
                        {
         ?>
         <tr>
            <td width="750" height=" 10"></td>
         </tr>
         <tr>
            <td width="750">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width=" 25"></td>
                  <td width=" 70"><p class="prnt" align="left"><b>Total</b></p></td>
                  <td width=" 10"></td>
                  <td width="540"><p class="prnt" align="left"><b><?php  echo $strGroup;     ?></b></p></td>
                  <td width=" 10"></td>
                  <td width=" 90"><p class="prnt" align="right"><b><?php echo $intGrpAmount; ?></b></p></td>
                  <td width="  5"></td>
               </tr>
               </table>
            </td>
         </tr>
         <tr>
            <td width="750" height=" 10"></td>
         </tr>
         <?php
                        }
                     }
                     
                     if($strReference    != $arrData[$intCount][0])
                     {
                        if($strReference != "")
                        {
         ?>
         <tr>
            <td width="750">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width="  5"></td>
                  <td width=" 90"><p class="prnt" align="left"><b>Total</b></p></td>
                  <td width=" 10"></td>
                  <td width="440"><p class="prnt" align="left"><b><?php  echo $strReference; ?></b></p></td>
                  <td width=" 10"></td>
                  <td width=" 90"><p class="prnt" align="right"><b><?php echo $intRefOffice != 0 ? $intRefOffice : ""; ?></b></p></td>
                  <td width=" 10"></td>
                  <td width=" 90"><p class="prnt" align="right"><b><?php echo $intRefClient != 0 ? $intRefClient : ""; ?></b></p></td>
                  <td width="  5"></td>
               </tr>
               </table>
            </td>
         </tr>
         <tr>
            <td width="750" height=" 10"></td>
         </tr>
         <tr>
            <td width="750" height="  1" background="images/spacer_01.gif""></td>
         </tr>
         <tr>
            <td width="750" height=" 10"></td>
         </tr>
         <?php
                        }
                     }
                     
                     if($strReference    != $arrData[$intCount][0])
                     {
         ?>
         <tr>
            <td width="750">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width="  5"></td>
                  <td width=" 90"><p class="prnt" align="left"><b>Tanggal</b></p></td>
                  <td width=" 10"></td>
                  <td width="640"><p class="prnt" align="left"><b><?php echo $arrData[$intCount][0]; ?></b></p></td>
                  <td width="  5"></td>
               </tr>
               </table>
            </td>
         </tr>
         <tr>
            <td width="750" height=" 10"></td>
         </tr>
         <?php
                     }
                     
                     if($strReference    != $arrData[$intCount][0] || $strGroup != $arrData[$intCount][1])
                     {
         ?>
         <tr>
            <td width="750">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width=" 25"></td>
                  <td width=" 70"><p class="prnt" align="left"><b>Klien</b></p></td>
                  <td width=" 10"></td>
                  <td width="640"><p class="prnt" align="left"><b><?php echo $arrData[$intCount][1]; ?></b></p></td>
                  <td width="  5"></td>
               </tr>
               </table>
            </td>
         </tr>
         <tr>
            <td width="750" height=" 10"></td>
         </tr>
         <?php
                     }
                     
                     if($strReference    != $arrData[$intCount][0] || $strGroup != $arrData[$intCount][1])
                     {
                        $intGrpAmount     = 0;
                        $strGroup         = $arrData[$intCount][1];
                     }
                     
                     if($strReference    != $arrData[$intCount][0])
                     {
                        $intRefOffice  = 0;
                        $intRefClient  = 0;
                        $strReference  = $arrData[$intCount][0];
                     }
         ?>
         <tr>
            <td width="750">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width=" 25"></td>
                  <td width=" 70">
                     <p class="prnt" align="left"><?php  echo $arrData[$intCount][2]; ?></p>
                  </td>
                  <td width=" 10"></td>
                  <td width="190">
                     <p class="prnt" align="left"><?php  echo $arrData[$intCount][3]; ?></p>
                  </td>
                  <td width=" 10"></td>
                  <td width=" 40">
                     <p class="prnt" align="right"><?php echo $arrData[$intCount][4]; ?></p>
                  </td>
                  <td width=" 10"></td>
                  <td width="140">
                     <p class="prnt" align="left"><?php  echo $arrData[$intCount][5]; ?></p>
                  </td>
                  <td width=" 10"></td>
                  <td width=" 90">
                     <p class="prnt" align="left"><?php  echo $arrData[$intCount][6]; ?></p>
                  </td>
                  <td width=" 10"></td>
                  <td width=" 90">
                     <p class="prnt" align="left"><?php  echo $arrData[$intCount][7]; ?></p>
                  </td>
                  <td width=" 10"></td>
                  <td width=" 40">
                     <p class="prnt" align="right"><?php echo $arrData[$intCount][8]; ?></p>
                  </td>
                  <td width="  5"></td>
               </tr>
               </table>
            </td>
         </tr>
         <?php
                     $intGrpAmount++;
                     
                     if($arrData[$intCount][1] != "Wawancara di Kantor")
                     {
                        $intRefClient++;
                        $intTotal[1]++;
                     } else {
                        $intRefOffice++;
                        $intTotal[0]++;
                     }
                  } else {
                     if($strReference      != $arrData[$intCount][0])
                     {
                        if($strReference   != "")
                        {
         ?>
         <tr>
            <td width="750" height=" 10"></td>
         </tr>
         <tr>
            <td width="750">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width="  5"></td>
                  <td width=" 90"><p class="prnt" align="left"><b>Total</b></p></td>
                  <td width=" 10"></td>
                  <td width="440"><p class="prnt" align="left"><b><?php  echo $strReference; ?></b></p></td>
                  <td width=" 10"></td>
                  <td width=" 90"><p class="prnt" align="right"><b><?php echo $intRefOffice != 0 ? $intRefOffice : ""; ?></b></p></td>
                  <td width=" 10"></td>
                  <td width=" 90"><p class="prnt" align="right"><b><?php echo $intRefClient != 0 ? $intRefClient : ""; ?></b></p></td>
                  <td width="  5"></td>
               </tr>
               </table>
            </td>
         </tr>
         <tr>
            <td width="750" height=" 10"></td>
         </tr>
         <tr>
            <td width="750" height="  1" background="images/spacer_01.gif""></td>
         </tr>
         <tr>
            <td width="750" height=" 10"></td>
         </tr>
         <?php
                        }
         ?>
         <tr>
            <td width="750">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width="  5"></td>
                  <td width=" 90"><p class="prnt" align="left"><b>Tanggal</b></p></td>
                  <td width=" 10"></td>
                  <td width="640"><p class="prnt" align="left"><b><?php echo $arrData[$intCount][0]; ?></b></p></td>
                  <td width="  5"></td>
               </tr>
               </table>
            </td>
         </tr>
         <tr>
            <td width="750" height=" 10"></td>
         </tr>
         <?php
                        $intRefOffice  = 0;
                        $intRefClient  = 0;
                        $strReference  = $arrData[$intCount][0];
                     }
         ?>
         <tr>
            <td width="750">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width="  5"></td>
                  <td width="540">
                     <p class="prnt" align="left"><?php  echo $arrData[$intCount][1]; ?></p>
                  </td>
                  <td width=" 10"></td>
                  <td width=" 90">
                     <p class="prnt" align="right"><?php echo $arrData[$intCount][1] != "Wawancara di Kantor" ? "" : $arrData[$intCount][2]; ?></p>
                  </td>
                  <td width=" 10"></td>
                  <td width=" 90">
                     <p class="prnt" align="right"><?php echo $arrData[$intCount][1] != "Wawancara di Kantor" ? $arrData[$intCount][2] : ""; ?></p>
                  </td>
                  <td width="  5"></td>
               </tr>
               </table>
            </td>
         </tr>
         <?php
                     if($arrData[$intCount][1] != "Wawancara di Kantor")
                     {
                        $intRefClient += $arrData[$intCount][2];
                        $intTotal[1]  += $arrData[$intCount][2];
                     } else {
                        $intRefOffice += $arrData[$intCount][2];
                        $intTotal[0]  += $arrData[$intCount][2];
                     }
                  }
               }
            }
            
            if($intRefOffice > 0 || $intRefClient > 0)
            {
               if($arrForm[3] == "DT")
               {
         ?>
         <tr>
            <td width="750" height=" 10"></td>
         </tr>
         <tr>
            <td width="750">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width=" 25"></td>
                  <td width=" 70"><p class="prnt" align="left"><b>Total</b></p></td>
                  <td width=" 10"></td>
                  <td width="540"><p class="prnt" align="left"><b><?php  echo $strGroup;     ?></b></p></td>
                  <td width=" 10"></td>
                  <td width=" 90"><p class="prnt" align="right"><b><?php echo $intGrpAmount; ?></b></p></td>
                  <td width="  5"></td>
               </tr>
               </table>
            </td>
         </tr>
         <tr>
            <td width="750" height=" 10"></td>
         </tr>
         <tr>
            <td width="750">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width="  5"></td>
                  <td width=" 90"><p class="prnt" align="left"><b>Total</b></p></td>
                  <td width=" 10"></td>
                  <td width="440"><p class="prnt" align="left"><b><?php  echo $strReference; ?></b></p></td>
                  <td width=" 10"></td>
                  <td width=" 90"><p class="prnt" align="right"><b><?php echo $intRefOffice != 0 ? $intRefOffice : ""; ?></b></p></td>
                  <td width=" 10"></td>
                  <td width=" 90"><p class="prnt" align="right"><b><?php echo $intRefClient != 0 ? $intRefClient : ""; ?></b></p></td>
                  <td width="  5"></td>
               </tr>
               </table>
            </td>
         </tr>
         <?php
               } else {
         ?>
         <tr>
            <td width="750" height=" 10"></td>
         </tr>
         <tr>
            <td width="750">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width="  5"></td>
                  <td width=" 90"><p class="prnt" align="left"><b>Total</b></p></td>
                  <td width=" 10"></td>
                  <td width="440"><p class="prnt" align="left"><b><?php  echo $strReference; ?></b></p></td>
                  <td width=" 10"></td>
                  <td width=" 90"><p class="prnt" align="right"><b><?php echo $intRefOffice != 0 ? $intRefOffice : ""; ?></b></p></td>
                  <td width=" 10"></td>
                  <td width=" 90"><p class="prnt" align="right"><b><?php echo $intRefClient != 0 ? $intRefClient : ""; ?></b></p></td>
                  <td width="  5"></td>
               </tr>
               </table>
            </td>
         </tr>
         <?php
               }
            }
         ?>
         </table>
      </td>
   </tr>
   <tr>
      <td width="750" height=" 10"></td>
   </tr>
   <tr>
      <td width="750" height="  1" background="images/spacer_01.gif""></td>
   </tr>
   <tr>
      <td width="750" height=" 10"></td>
   </tr>
   <tr>
      <td width="750">
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <tr>
            <td width="  5"></td>
            <td width="540"><p class="prnt" align="left"><b>Grand Total</b></p></td>
            <td width=" 10"></td>
            <td width=" 90"><p class="prnt" align="right"><b><?php echo $intTotal[0]; ?></b></p></td>
            <td width=" 10"></td>
            <td width=" 90"><p class="prnt" align="right"><b><?php echo $intTotal[1]; ?></b></p></td>
            <td width="  5"></td>
         </tr>
         </table>
      </td>
   </tr>
   <tr>
      <td width="750" height=" 10"></td>
   </tr>
   <tr>
      <td width="750" height="  1" background="images/spacer_01.gif"></td>
   </tr>
   <tr>
      <td width="750" height=" 20"></td>
   </tr>
   </table>
   </center></div>
</body>

</html>