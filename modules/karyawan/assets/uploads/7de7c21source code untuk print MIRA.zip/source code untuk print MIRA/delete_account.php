<?php ob_start();                     ?>
<?php session_start();                ?>
<?php include "data/condata.php";     ?>
<?php include "modules/function.php"; ?>

<?php
   if(!$_SESSION['LOGIN'])
   {
      header("Location:login.php");
   }
   
   $strReference       = $_GET['ref'];
   $strObject          = str_replace("%", "&", $_GET['obj']);
   
   $qrDelete           = "DELETE FROM Ms_User WHERE (UPPER(User_Reference) = UPPER('$strReference')) ORDER BY User_Reference";
   $rsDelete           = mysql_query($qrDelete);
   
   header("Location:lookup_account.php?$strObject");
?>