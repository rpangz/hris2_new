<?php ob_start();                     ?>
<?php session_start();                ?>
<?php include "data/condata.php";     ?>

<?php
   if($_SESSION['LOGIN'])
   {
      switch($_SESSION['PAGES'])
      {
         case "0000"    : header("Location:detail_password.php");
                          break;
         case "0100"    : header("Location:lookup_registrar.php");
                          break;
         case "0200"    : header("Location:lookup_interview.php");
                          break;
         case "0300"    : header("Location:lookup_resources.php");
                          break;
         case "0400"    : header("Location:lookup_reports.php");
                          break;
      }
   }
   
   if($_POST)
   {
      $arrData[0]       = addslashes($_POST['00']);
      $arrData[1]       = addslashes($_POST['01']);
      
      $qrData           = "SELECT * FROM Ms_User WHERE (UPPER(User_Reference) = UPPER('$arrData[0]')) ".
                                 "AND (CONVERT(IFNULL(User_Password, ''), BINARY(20)) = CONVERT(IFNULL('$arrData[1]', ''), BINARY(20))) ".
                          "ORDER BY User_Reference";
      
      $rsData           = mysql_query($qrData);
      
      while($arrFields  = mysql_fetch_array($rsData))
      {
         $arrData[2]    = stripslashes($arrFields[3]);
         $arrData[3]    = stripslashes($arrFields[4]);
         $arrData[4]    = stripslashes($arrFields[5]);
         $arrData[5]    = stripslashes($arrFields[6]);
      }
      
      if(mysql_num_rows($rsData)   == 0)
      {
         $strError     .= "Login tidak benar. Pastikan Login adalah benar.<br>";
      }
      
      if(!$strError)
      {
         $strDefault    = "0000";
         
         if($arrData[5])
         {
            $strDefault = "0400";
         }
         
         if($arrData[4])
         {
            $strDefault = "0300";
         }
         
         if($arrData[3])
         {
            $strDefault = "0200";
         }
         
         if($arrData[2])
         {
            $strDefault = "0100";
         }
         
         $_SESSION['LOGIN']         = $arrData[0];
         $_SESSION['PERMISSION_01'] = $arrData[2];
         $_SESSION['PERMISSION_02'] = $arrData[3];
         $_SESSION['PERMISSION_03'] = $arrData[4];
         $_SESSION['PERMISSION_04'] = $arrData[5];
         $_SESSION['LEVEL']         = $arrData[0] == "administrator" ? 1 : 0;
         $_SESSION['PAGES']         = $strDefault;
         
         switch($strDefault)
         {
            case "0000" : header("Location:detail_password.php");
                          break;
            case "0100" : header("Location:lookup_registrar.php");
                          break;
            case "0200" : header("Location:lookup_interview.php");
                          break;
            case "0300" : header("Location:lookup_resources.php");
                          break;
            case "0400" : header("Location:lookup_reports.php");
                          break;
         }
      }
      
      $arrData[0]       = stripslashes($_POST['00']);
      $arrData[1]       = stripslashes($_POST['01']);
   }
?>

<html>

<head>
   <meta http-equiv="Content-Language" content="en-us">
   <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
   <meta name="Keywords" content="Bursa Kerja, Career, Calon Karyawan, Cari Kerja, HRD, Human Resources, Indonesia, Interview, Jobs, Job Fair, Job Seeker, Karir, Kinerja, Lowongan, Outsources, Outsourcing, Recruitments, Relasi, Relationships, Resources, SDM, Sumber Daya Manusia, Tenaga Kerja, Wawancara">
   <meta name="Description" content="Indonesia's Best Outsourcing">
   <meta name="Author" content="Exteron Corporation">
   <title>..:: PT Jasmine Indonesia ::..</title>
   <link href="style.css" type="text/css" rel="stylesheet">
</head>


<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" background="images/back_01.gif">
   <table cellpadding="0" cellspacing="0" border="0" width="100%">
   <tr>
      <td width="100%" background="images/back_01.gif">
         <div align="center"><center>
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <tr>
            <td width="750" height="100" background="images/logo.gif"><a href="../index.php?ref=&var=RG&obj=<?php echo $strObject ; ?>"></a><a href="../index.php?ref=&var=RG&obj=<?php echo $strObject ; ?>"><img
                              src="images/home.png" width="50" height="50" border="0" align="right"></a></td>
         </tr>
         </table>
                  </center></div>
      </td>
   </tr>
   
   <tr>
      <td width="100%" background="images/back_02.gif">
         <div align="center"><center>
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <tr>
            <td width="750" background="images/back_04.gif">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <form name="form" method="post">
               <?php
                  if(!$strError)
                  {
               ?>
               <tr>
                  <td width="210" height="170"></td>
                  <td width="330" height="170"></td>
                  <td width="210" height="170"></td>
               </tr>
               <?php
                  } else {
               ?>
               
               <tr>
                  <td width="210" height="135"></td>
                  <td width="330" height="135"></td>
                  <td width="210" height="135"></td>
               </tr>
               <tr>
                  <td width="210"></td>
                  <td width="330">
                     <p class="form" align="left"><?php echo $strError; ?></p>
                  </td>
                  <td width="210"></td>
               </tr>
               <tr>
                  <td width="210" height=" 20"></td>
                  <td width="330" height=" 20"></td>
                  <td width="210" height=" 20"></td>
               </tr>
               <?php
                  }
               ?>
               
               <tr>
                  <td width="210"></td>
                  <td width="330">
                     <table cellpadding="0" cellspacing="0" border="0" width="330">
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Nama Pengguna</p>
                        </td>
                        <td width="130" height="25">
                           <p align="left">
                              <input class="form" type="text" name="00" size="20" maxlength="20" value="<?php echo $arrData[0]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Kata Sandi</p>
                        </td>
                        <td width="130" height="25">
                           <p align="left">
                              <input class="form" type="password" name="01" size="20" maxlength="20">
                           </p>
                        </td>
                     </tr>
                     </table>
                  </td>
                  <td width="210"></td>
               </tr>
               <tr>
                  <td width="210" height=" 20"></td>
                  <td width="330" height=" 20"></td>
                  <td width="210" height=" 20"></td>
               </tr>
               <tr>
                  <td width="210"></td>
                  <td width="330">
                     <p align="right">
                        <input type="image" name="02" src="images/button_06.gif" width="90" height="30">
                     </p>
                  </td>
                  <td width="210"></td>
               </tr>
               <tr>
                  <td width="210" height="170"></td>
                  <td width="330" height="170"></td>
                  <td width="210" height="170"></td>
               </tr>
               </table>
            </td>
         </tr>
         </table>
         </center></div>
      </td>
   </tr>
   <tr>
      <td width="100%" background="images/back_01.gif">
         <div align="center"><center>
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <tr>
            <td width="750" background="images/back_03.gif">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750">
                     <p class="foot" align="right">
                        <a class="foot" ></a> � 2013 Untuk Skripsi
                     </p>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               </table>
            </td>
         </tr>
         </table>
         </center></div>
      </td>
   </tr>
   </table>
</body>

</html>