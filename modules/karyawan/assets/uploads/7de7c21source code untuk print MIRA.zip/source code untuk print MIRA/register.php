<?php ob_start();                     ?>
<?php session_start();                ?>
<?php include "admin/data/condata.php";     ?>
<?php include "admin/modules/function.php"; ?>
<?php include "admin/modules/function.js";  ?>

<?php
  
   
   $qrData             = "SELECT Ms_Card.*, Ms_Interview.*, ".
                                "YEAR(NOW()) - YEAR(Ms_Card.Card_Date) AS Card_Age ".
                         "FROM  (Ms_Card LEFT JOIN Ms_Interview ON Ms_Card.Card_Reference = Ms_Interview.Interview_Card) ".
                         "WHERE (Ms_Card.Card_Reference = '$strReference') AND (Ms_Card.Card_Type = '$strVariable') ".
                         "ORDER BY Ms_Card.Card_Reference";
   
   $rsData             = mysql_query($qrData);
   
   $arrData[0]         = stripslashes("[ Auto Number ]");
   $arrData[3]         = stripslashes(date("d"));
   $arrData[4]         = stripslashes(date("m"));
   $arrData[5]         = stripslashes(date("Y"));
   $arrData[10]        = stripslashes("0");
   $arrData[57]        = stripslashes(date("d"));
   $arrData[58]        = stripslashes(date("m"));
   $arrData[59]        = stripslashes(date("Y"));
   $arrData[90]        = stripslashes("0");
   $arrData[91]        = stripslashes("0");
   
   while($arrFields    = mysql_fetch_array($rsData))
   {
      $arrDate[0]      = explode(" ", $arrFields[4]);
      $arrDate[1]      = explode(" ", $arrFields[64]);
      $arrDate[2]      = explode(" ", $arrFields[96]);
      $arrDate[3]      = explode(" ", $arrFields[101]);
      $arrDate[4]      = explode(" ", $arrFields[94]);
      
      $arrDate[0]      = explode("-", $arrDate[0][0]);
      $arrDate[1]      = explode("-", $arrDate[1][0]);
      $arrDate[2]      = explode("-", $arrDate[2][0]);
      $arrDate[3]      = explode("-", $arrDate[3][0]);
      $arrDate[4]      = explode("-", $arrDate[4][0]);
      
      $arrData[0]      = stripslashes($arrFields[0]);
      $arrData[1]      = stripslashes($arrFields[2]);
      $arrData[2]      = stripslashes($arrFields[3]);
      $arrData[3]      = stripslashes($arrDate[0][2]);
      $arrData[4]      = stripslashes($arrDate[0][1]);
      $arrData[5]      = stripslashes($arrDate[0][0]);
      $arrData[6]      = stripslashes($arrFields[5]);
      $arrData[7]      = stripslashes($arrFields[6]);
      $arrData[8]      = stripslashes($arrFields[7]);
      $arrData[9]      = stripslashes($arrFields[8]);
      $arrData[10]     = stripslashes($arrFields[9]);
      $arrData[11]     = stripslashes($arrFields[10]);
      $arrData[12]     = stripslashes($arrFields[11]);
      $arrData[13]     = stripslashes($arrFields[12]);
      $arrData[14]     = stripslashes($arrFields[13]);
      $arrData[15]     = stripslashes($arrFields[14]);
      $arrData[16]     = stripslashes($arrFields[15]);
      $arrData[17]     = stripslashes($arrFields[16]);
      $arrData[18]     = stripslashes($arrFields[17]);
      $arrData[19]     = stripslashes($arrFields[18]);
      $arrData[20]     = stripslashes($arrFields[19]);
      $arrData[21]     = stripslashes($arrFields[20]);
      $arrData[22]     = stripslashes($arrFields[21]);
      $arrData[23]     = stripslashes($arrFields[82]);
      $arrData[24]     = stripslashes($arrFields[23]);
      $arrData[25]     = stripslashes($arrFields[24]);
      $arrData[26]     = stripslashes($arrFields[25]);
      $arrData[27]     = stripslashes($arrFields[26]);
      $arrData[28]     = stripslashes($arrFields[27]);
      $arrData[29]     = stripslashes($arrFields[28]);
      $arrData[30]     = stripslashes($arrFields[29]);
      $arrData[31]     = stripslashes($arrFields[30]);
      $arrData[32]     = stripslashes($arrFields[31]);
      $arrData[33]     = stripslashes($arrFields[32]);
      $arrData[34]     = stripslashes($arrFields[33]);
      $arrData[35]     = stripslashes($arrFields[34]);
      $arrData[36]     = stripslashes($arrFields[35]);
      $arrData[37]     = stripslashes($arrFields[36]);
      $arrData[38]     = stripslashes($arrFields[37]);
      $arrData[39]     = stripslashes($arrFields[38]);
      $arrData[40]     = stripslashes($arrFields[39]);
      $arrData[41]     = stripslashes($arrFields[40]);
      $arrData[42]     = stripslashes($arrFields[41]);
      $arrData[43]     = stripslashes($arrFields[42]);
      $arrData[44]     = stripslashes($arrFields[43]);
      $arrData[45]     = stripslashes($arrFields[44]);
      $arrData[46]     = stripslashes($arrFields[45]);
      $arrData[47]     = stripslashes($arrFields[46]);
      $arrData[48]     = stripslashes($arrFields[47]);
      $arrData[49]     = stripslashes($arrFields[48]);
      $arrData[50]     = stripslashes($arrFields[49]);
      $arrData[51]     = stripslashes($arrFields[50]);
      $arrData[52]     = stripslashes($arrFields[51]);
      $arrData[53]     = stripslashes($arrFields[52]);
      $arrData[54]     = stripslashes($arrFields[53]);
      $arrData[55]     = stripslashes($arrFields[54]);
      $arrData[56]     = stripslashes($arrFields[62]);
      $arrData[57]     = stripslashes($arrFields[63]);
      $arrData[58]     = stripslashes($arrDate[1][2]);
      $arrData[59]     = stripslashes($arrDate[1][1]);
      $arrData[60]     = stripslashes($arrDate[1][0]);
      $arrData[61]     = stripslashes($arrFields[65]);
      $arrData[62]     = stripslashes($arrFields[66]);
      $arrData[63]     = stripslashes($arrFields[67]);
      $arrData[64]     = stripslashes($arrFields[68]);
      $arrData[65]     = stripslashes($arrFields[69]);
      $arrData[66]     = stripslashes($arrFields[70]);
      $arrData[67]     = stripslashes($arrFields[71]);
      $arrData[68]     = stripslashes($arrFields[72]);
      $arrData[69]     = stripslashes($arrFields[55]);
      $arrData[70]     = stripslashes($arrFields[56]);
      $arrData[71]     = stripslashes($arrFields[57]);
      $arrData[72]     = stripslashes($arrFields[58]);
      $arrData[73]     = stripslashes($arrFields[59]);
      $arrData[74]     = stripslashes($arrFields[60]);
      $arrData[75]     = stripslashes($arrFields[61]);
      $arrData[76]     =   RenBoolean($arrFields[84]);
      $arrData[77]     =   RenBoolean($arrFields[85]);
      $arrData[78]     =   RenBoolean($arrFields[86]);
      $arrData[79]     =   RenBoolean($arrFields[87]);
      $arrData[80]     =   RenBoolean($arrFields[88]);
      $arrData[81]     =   RenBoolean($arrFields[89]);
      $arrData[82]     =   RenBoolean($arrFields[90]);
      $arrData[83]     =   RenBoolean($arrFields[91]);
      $arrData[84]     =   RenBoolean($arrFields[92]);
      $arrData[85]     =   RenBoolean($arrFields[93]);
      $arrData[86]     = stripslashes($arrFields[93]);
      $arrData[87]     = stripslashes($arrFields[73]);
      $arrData[88]     = stripslashes($arrFields[74]);
      $arrData[89]     = stripslashes($arrFields[75]);
      $arrData[90]     = stripslashes($arrFields[76]);
      $arrData[91]     = stripslashes($arrFields[77]);
      $arrData[92]     = stripslashes($arrFields[78]);
      $arrData[93]     =   RenBoolean($arrFields[83]);
      $arrData[94]     = stripslashes($arrFields[81]);
      $arrData[95]     = stripslashes($arrFields[79]);
      $arrData[96]     = stripslashes($arrFields[80]);
      $arrData[97]     = stripslashes($arrFields[01]);
      $arrData[98]     =   RenBoolean($arrFields[22]);
      $arrData[99]     = stripslashes($arrFields[22]);
      $arrData[100]    = stripslashes($arrDate[2][2] ." ". $arrMonth[intval($arrDate[2][1])] ." ". $arrDate[2][0]);
      $arrData[101]    = stripslashes($arrDate[3][2] ." ". $arrMonth[intval($arrDate[3][1])] ." ". $arrDate[3][0]);
      $arrData[102]    = stripslashes($arrDate[4][2] ." ". $arrMonth[intval($arrDate[4][1])] ." ". $arrDate[4][0]);
      $arrData[103]    = stripslashes($arrFields[105]);
   }
   
   if($_POST)
   {
      $arrData[0]      = addslashes($_POST['00']);
      $arrData[1]      = addslashes($_POST['01']);
      $arrData[2]      = addslashes($_POST['02']);
      $arrData[3]      = addslashes($_POST['03']);
      $arrData[4]      = addslashes($_POST['04']);
      $arrData[5]      = addslashes($_POST['05']);
      $arrData[6]      = addslashes($_POST['06']);
      $arrData[7]      = addslashes($_POST['07']);
      $arrData[8]      = addslashes($_POST['08']);
      $arrData[9]      = addslashes($_POST['09']);
      $arrData[10]     = addslashes($_POST['10']);
      $arrData[11]     = addslashes($_POST['11']);
      $arrData[12]     = addslashes($_POST['12']);
      $arrData[13]     = addslashes($_POST['13']);
      $arrData[14]     = addslashes($_POST['14']);
      $arrData[15]     = addslashes($_POST['15']);
      $arrData[16]     = addslashes($_POST['16']);
      $arrData[17]     = addslashes($_POST['17']);
      $arrData[18]     = addslashes($_POST['18']);
      $arrData[19]     = addslashes($_POST['19']);
      $arrData[20]     = addslashes($_POST['20']);
      $arrData[21]     = addslashes($_POST['21']);
      $arrData[22]     = addslashes($_POST['22']);
   /* $arrData[23]     = addslashes($_POST['23']); */
      $arrData[24]     = addslashes($_POST['24']);
      $arrData[25]     = addslashes($_POST['25']);
      $arrData[26]     = addslashes($_POST['26']);
      $arrData[27]     = addslashes($_POST['27']);
      $arrData[28]     = addslashes($_POST['28']);
      $arrData[29]     = addslashes($_POST['29']);
      $arrData[30]     = addslashes($_POST['30']);
      $arrData[31]     = addslashes($_POST['31']);
      $arrData[32]     = addslashes($_POST['32']);
      $arrData[33]     = addslashes($_POST['33']);
      $arrData[34]     = addslashes($_POST['34']);
      $arrData[35]     = addslashes($_POST['35']);
      $arrData[36]     = addslashes($_POST['36']);
      $arrData[37]     = addslashes($_POST['37']);
      $arrData[38]     = addslashes($_POST['38']);
      $arrData[39]     = addslashes($_POST['39']);
      $arrData[40]     = addslashes($_POST['40']);
      $arrData[41]     = addslashes($_POST['41']);
      $arrData[42]     = addslashes($_POST['42']);
      $arrData[43]     = addslashes($_POST['43']);
      $arrData[44]     = addslashes($_POST['44']);
      $arrData[45]     = addslashes($_POST['45']);
      $arrData[46]     = addslashes($_POST['46']);
      $arrData[47]     = addslashes($_POST['47']);
      $arrData[48]     = addslashes($_POST['48']);
      $arrData[49]     = addslashes($_POST['49']);
      $arrData[50]     = addslashes($_POST['50']);
      $arrData[51]     = addslashes($_POST['51']);
      $arrData[52]     = addslashes($_POST['52']);
      $arrData[53]     = addslashes($_POST['53']);
      $arrData[54]     = addslashes($_POST['54']);
      $arrData[55]     = addslashes($_POST['55']);
      $arrData[56]     = addslashes($_POST['56']);
      $arrData[57]     = addslashes($_POST['57']);
      $arrData[58]     = addslashes($_POST['58']);
      $arrData[59]     = addslashes($_POST['59']);
      $arrData[60]     = addslashes($_POST['60']);
      $arrData[61]     = addslashes($_POST['61']);
      $arrData[62]     = addslashes($_POST['62']);
      $arrData[63]     = addslashes($_POST['63']);
      $arrData[64]     = addslashes($_POST['64']);
      $arrData[65]     = addslashes($_POST['65']);
      $arrData[66]     = addslashes($_POST['66']);
      $arrData[67]     = addslashes($_POST['67']);
      $arrData[68]     = addslashes($_POST['68']);
      $arrData[69]     = addslashes($_POST['69']);
      $arrData[70]     = addslashes($_POST['70']);
      $arrData[71]     = addslashes($_POST['71']);
      $arrData[72]     = addslashes($_POST['72']);
      $arrData[73]     = addslashes($_POST['73']);
      $arrData[74]     = addslashes($_POST['74']);
      $arrData[75]     = addslashes($_POST['75']);
      $arrData[76]     = RenBoolean($_POST['76']);
      $arrData[77]     = RenBoolean($_POST['77']);
      $arrData[78]     = RenBoolean($_POST['78']);
      $arrData[79]     = RenBoolean($_POST['79']);
      $arrData[80]     = RenBoolean($_POST['80']);
      $arrData[81]     = RenBoolean($_POST['81']);
      $arrData[82]     = RenBoolean($_POST['82']);
      $arrData[83]     = RenBoolean($_POST['83']);
      $arrData[84]     = RenBoolean($_POST['84']);
      $arrData[85]     = RenBoolean($_POST['85']);
      $arrData[86]     = addslashes($_POST['86']);
      $arrData[87]     = addslashes($_POST['87']);
      $arrData[88]     = addslashes($_POST['88']);
      $arrData[89]     = addslashes($_POST['89']);
      $arrData[90]     = addslashes($_POST['90']);
      $arrData[91]     = addslashes($_POST['91']);
      $arrData[92]     = addslashes($_POST['92']);
      $arrData[93]     = RenBoolean($_POST['93']);
      $arrData[94]     = addslashes($_POST['94']);
      $arrData[95]     = addslashes($_POST['95']);
      $arrData[96]     = addslashes($_POST['96']);
      $arrData[97]     = addslashes($_POST['97']);
      $arrData[98]     = RenBoolean($_POST['98']);
      $arrData[99]     = addslashes($_POST['99']);
      $arrData[100]    = addslashes($_POST['100']);
      $arrData[101]    = addslashes($_POST['101']);
      $arrData[102]    = addslashes($_POST['102']);
      $arrData[103]    = addslashes($_POST['103']);
      
      if($arrData[1]  == "")
      {
         $strError    .= "Nama Lengkap (sesuai KTP) tidak ada. Isilah Nama Lengkap (sesuai KTP).<br>";
      }
      
      if(!checkdate($arrData[4], $arrData[3], $arrData[5]))
      {
         $strError    .= "Pilihan Tanggal Lahir tidak benar. Pastikan Tanggal Lahir adalah format tanggal.<br>";
      }
      
      if(!is_numeric($arrData[10]))
      {
         $strError    .= "Jumlah Anak (bila ada) tidak benar. Pastikan Jumlah Anak (bila ada) adalah format angka.<br>";
      }
      
      if($arrData[11] == "")
      {
         $strError    .= "Alamat tidak ada. Isilah Alamat.<br>";
      }
      
      if($arrData[16] == "")
      {
         $strError    .= "No. Telp tidak ada. Isilah No. Telp.<br>";
      }
      
      if($arrData[17] == "")
      {
         $strError    .= "No. Ponsel tidak ada. Isilah No. Ponsel.<br>";
      }
      
      if($arrData[18] != "" && !eregi("^.+@.+\\..+$", $arrData[18]))
      {
         $strError    .= "Email tidak benar. Pastikan Email benar.<br>";
      }
      
      if($arrData[24] == "")
      {
         $strError    .= "SMU / Perguruan Tinggi tidak ada. Isilah SMU / Perguruan Tinggi.<br>";
      }
      
      if($arrData[48] == "")
      {
         $strError    .= "Nama Ayah Kandung tidak ada. Isilah Nama Ayah Kandung.<br>";
      }
      
      if($arrData[49] == "")
      {
         $strError    .= "Nama Ibu Kandung tidak ada. Isilah Nama Ibu Kandung.<br>";
      }
      
      if($arrData[55] == "")
      {
         $strError    .= "No. Telp tidak ada. Isilah No. Telp.<br>";
      }
      
      if(!checkdate($arrData[59], $arrData[58], $arrData[60]))
      {
         $strError    .= "Pilihan Tanggal Lahir tidak benar. Pastikan Tanggal Lahir adalah format tanggal.<br>";
      }
      
      if($arrData[69] == "")
      {
         $strError    .= "Nama (Keadaan Darurat) tidak ada. Isilah Nama (Keadaan Darurat).<br>";
      }
      
      
      if($arrData[75] == "")
      {
         $strError    .= "No. Telp tidak ada. Isilah No. Telp.<br>";
      }
      
      if($strVariable == "EM" || $strVariable == "RS")
      {
         if(!is_numeric($arrData[91]))
         {
            $strError .= "Lama Kontrak tidak benar. Pastikan Lama Kontrak adalah format angka.<br>";
         }
         
         if(!is_numeric($arrData[92]))
         {
            $strError .= "Upah / Gaji tidak benar. Pastikan Upah / Gaji adalah format angka.<br>";
         }
      }
      
      if(!$strError)
      {
         $arrData[0]   = SetReference("RG");
         $arrData[97]  = $arrData[97] != "" ? $arrData[97] : "RG";
         $arrData[99]  = $arrData[99] != 0  ? $arrData[99] : "";
         
         if($_FILES['23']['name'])
         {
            $objExt      =  explode(".", $_FILES['23']['name']);
            $arrData[23] =  mysql_num_rows($rsData) > 0 ? $strReference : $arrData[0];
            $arrData[23] = "admin/data//". str_replace("/", "", $arrData[23]) .".". $objExt[1];
         }
         
         if(mysql_num_rows($rsData) > 0)
         {
            $qrInput   = "UPDATE Ms_Card SET                                                             ".
                                "Card_Type          = '$arrData[97]'                                   , ".
                                "Card_Name          = '$arrData[1]'                                    , ".
                                "Card_Birth         = '$arrData[2]'                                    , ".
                                "Card_Date          = '$arrData[5]-$arrData[4]-$arrData[3] 00:00:00'   , ".
                                "Card_Code          = '$arrData[6]'                                    , ".
                                "Card_Gender        = '$arrData[7]'                                    , ".
                                "Card_Religion      = '$arrData[8]'                                    , ".
                                "Card_Relation      = '$arrData[9]'                                    , ".
                                "Card_Children      = '$arrData[10]'                                   , ".
                                "Card_Address       = '$arrData[11]'                                   , ".
                                "Card_LAU           = '$arrData[12]'                                   , ".
                                "Card_City          = '$arrData[13]'                                   , ".
                                "Card_Postal        = '$arrData[14]'                                   , ".
                                "Card_State         = '$arrData[15]'                                   , ".
                                "Card_Phone         = '$arrData[16]'                                   , ".
                                "Card_Mobile        = '$arrData[17]'                                   , ".
                                "Card_Email         = '$arrData[18]'                                   , ".
                                "Card_House         = '$arrData[19]'                                   , ".
                                "Card_Vehicle       = '$arrData[20]'                                   , ".
                                "Card_Interest      = '$arrData[21]'                                   , ".
                                "Card_Advertize     = '$arrData[22]'                                   , ".
                                "Card_Newsletter    = '$arrData[99]'                                   , ".
                                "Card_1st_College   = '$arrData[24]'                                   , ".
                                "Card_1st_Major     = '$arrData[25]'                                   , ".
                                "Card_1st_Year      = '$arrData[26]'                                   , ".
                                "Card_1st_Grade     = '$arrData[27]'                                   , ".
                                "Card_2nd_College   = '$arrData[28]'                                   , ".
                                "Card_2nd_Major     = '$arrData[29]'                                   , ".
                                "Card_2nd_Year      = '$arrData[30]'                                   , ".
                                "Card_2nd_Grade     = '$arrData[31]'                                   , ".
                                "Card_3rd_College   = '$arrData[32]'                                   , ".
                                "Card_3rd_Major     = '$arrData[33]'                                   , ".
                                "Card_3rd_Year      = '$arrData[34]'                                   , ".
                                "Card_3rd_Grade     = '$arrData[35]'                                   , ".
                                "Card_1st_Company   = '$arrData[36]'                                   , ".
                                "Card_1st_Line      = '$arrData[37]'                                   , ".
                                "Card_1st_Title     = '$arrData[38]'                                   , ".
                                "Card_1st_Period    = '$arrData[39]'                                   , ".
                                "Card_2nd_Company   = '$arrData[40]'                                   , ".
                                "Card_2nd_Line      = '$arrData[41]'                                   , ".
                                "Card_2nd_Title     = '$arrData[42]'                                   , ".
                                "Card_2nd_Period    = '$arrData[43]'                                   , ".
                                "Card_3rd_Company   = '$arrData[44]'                                   , ".
                                "Card_3rd_Line      = '$arrData[45]'                                   , ".
                                "Card_3rd_Title     = '$arrData[46]'                                   , ".
                                "Card_3rd_Period    = '$arrData[47]'                                   , ".
                                "Card_1st_Father    = '$arrData[48]'                                   , ".
                                "Card_1st_Mother    = '$arrData[49]'                                   , ".
                                "Card_1st_Address   = '$arrData[50]'                                   , ".
                                "Card_1st_LAU       = '$arrData[51]'                                   , ".
                                "Card_1st_City      = '$arrData[52]'                                   , ".
                                "Card_1st_Postal    = '$arrData[53]'                                   , ".
                                "Card_1st_State     = '$arrData[54]'                                   , ".
                                "Card_1st_Phone     = '$arrData[55]'                                   , ".
                                "Card_2nd_Family    = '$arrData[69]'                                   , ".
                                "Card_2nd_Address   = '$arrData[70]'                                   , ".
                                "Card_2nd_LAU       = '$arrData[71]'                                   , ".
                                "Card_2nd_City      = '$arrData[72]'                                   , ".
                                "Card_2nd_Postal    = '$arrData[73]'                                   , ".
                                "Card_2nd_State     = '$arrData[74]'                                   , ".
                                "Card_2nd_Phone     = '$arrData[75]'                                   , ".
                                "Card_3rd_Spouse    = '$arrData[56]'                                   , ".
                                "Card_3rd_Birth     = '$arrData[57]'                                   , ".
                                "Card_3rd_Date      = '$arrData[60]-$arrData[59]-$arrData[58] 00:00:00', ".
                                "Card_3rd_Job       = '$arrData[61]'                                   , ".
                                "Card_3rd_Corporate = '$arrData[62]'                                   , ".
                                "Card_3rd_Address   = '$arrData[63]'                                   , ".
                                "Card_3rd_LAU       = '$arrData[64]'                                   , ".
                                "Card_3rd_City      = '$arrData[65]'                                   , ".
                                "Card_3rd_Postal    = '$arrData[66]'                                   , ".
                                "Card_3rd_State     = '$arrData[67]'                                   , ".
                                "Card_3rd_Phone     = '$arrData[68]'                                   , ".
                                "Card_Register      = '$arrData[87]'                                   , ".
                                "Card_Company       = '$arrData[88]'                                   , ".
                                "Card_Branch        = '$arrData[89]'                                   , ".
                                "Card_Title         = '$arrData[90]'                                   , ".
                                "Card_Contract      = '$arrData[91]'                                   , ".
                                "Card_Wages         = '$arrData[92]'                                   , ".
                                "Card_AC            = '$arrData[95]'                                   , ".
                                "Card_AN            = '$arrData[96]'                                   , ".
                                "Card_Bank          = '$arrData[94]'                                   , ".
                                "Card_Picture       = '$arrData[23]'                                   , ".
                                "Card_Paid          = '$arrData[93]'                                   , ".
                                "Card_Docs_01       = '$arrData[76]'                                   , ".
                                "Card_Docs_02       = '$arrData[77]'                                   , ".
                                "Card_Docs_03       = '$arrData[78]'                                   , ".
                                "Card_Docs_04       = '$arrData[79]'                                   , ".
                                "Card_Docs_05       = '$arrData[80]'                                   , ".
                                "Card_Docs_06       = '$arrData[81]'                                   , ".
                                "Card_Docs_07       = '$arrData[82]'                                   , ".
                                "Card_Docs_08       = '$arrData[83]'                                   , ".
                                "Card_Docs_09       = '$arrData[84]'                                   , ".
                                "Card_Docs_10       = '$arrData[86]'                                   , ".
                                "Card_2nd_User      = '$strUserName'                                   , ".
                                "Card_2nd_Date      =  now()                                             ".
                         "WHERE (Card_Reference     = '$strReference')                                   ";
         } else {
            $qrInput   = "INSERT INTO Ms_Card SET                                                        ".
                                "Card_Reference     = '$arrData[0]'                                    , ".
                                "Card_Type          = '$arrData[97]'                                   , ".
                                "Card_Name          = '$arrData[1]'                                    , ".
                                "Card_Birth         = '$arrData[2]'                                    , ".
                                "Card_Date          = '$arrData[5]-$arrData[4]-$arrData[3] 00:00:00'   , ".
                                "Card_Code          = '$arrData[6]'                                    , ".
                                "Card_Gender        = '$arrData[7]'                                    , ".
                                "Card_Religion      = '$arrData[8]'                                    , ".
                                "Card_Relation      = '$arrData[9]'                                    , ".
                                "Card_Children      = '$arrData[10]'                                   , ".
                                "Card_Address       = '$arrData[11]'                                   , ".
                                "Card_LAU           = '$arrData[12]'                                   , ".
                                "Card_City          = '$arrData[13]'                                   , ".
                                "Card_Postal        = '$arrData[14]'                                   , ".
                                "Card_State         = '$arrData[15]'                                   , ".
                                "Card_Phone         = '$arrData[16]'                                   , ".
                                "Card_Mobile        = '$arrData[17]'                                   , ".
                                "Card_Email         = '$arrData[18]'                                   , ".
                                "Card_House         = '$arrData[19]'                                   , ".
                                "Card_Vehicle       = '$arrData[20]'                                   , ".
                                "Card_Interest      = '$arrData[21]'                                   , ".
                                "Card_Advertize     = '$arrData[22]'                                   , ".
                                "Card_Newsletter    = '$arrData[99]'                                   , ".
                                "Card_1st_College   = '$arrData[24]'                                   , ".
                                "Card_1st_Major     = '$arrData[25]'                                   , ".
                                "Card_1st_Year      = '$arrData[26]'                                   , ".
                                "Card_1st_Grade     = '$arrData[27]'                                   , ".
                                "Card_2nd_College   = '$arrData[28]'                                   , ".
                                "Card_2nd_Major     = '$arrData[29]'                                   , ".
                                "Card_2nd_Year      = '$arrData[30]'                                   , ".
                                "Card_2nd_Grade     = '$arrData[31]'                                   , ".
                                "Card_3rd_College   = '$arrData[32]'                                   , ".
                                "Card_3rd_Major     = '$arrData[33]'                                   , ".
                                "Card_3rd_Year      = '$arrData[34]'                                   , ".
                                "Card_3rd_Grade     = '$arrData[35]'                                   , ".
                                "Card_1st_Company   = '$arrData[36]'                                   , ".
                                "Card_1st_Line      = '$arrData[37]'                                   , ".
                                "Card_1st_Title     = '$arrData[38]'                                   , ".
                                "Card_1st_Period    = '$arrData[39]'                                   , ".
                                "Card_2nd_Company   = '$arrData[40]'                                   , ".
                                "Card_2nd_Line      = '$arrData[41]'                                   , ".
                                "Card_2nd_Title     = '$arrData[42]'                                   , ".
                                "Card_2nd_Period    = '$arrData[43]'                                   , ".
                                "Card_3rd_Company   = '$arrData[44]'                                   , ".
                                "Card_3rd_Line      = '$arrData[45]'                                   , ".
                                "Card_3rd_Title     = '$arrData[46]'                                   , ".
                                "Card_3rd_Period    = '$arrData[47]'                                   , ".
                                "Card_1st_Father    = '$arrData[48]'                                   , ".
                                "Card_1st_Mother    = '$arrData[49]'                                   , ".
                                "Card_1st_Address   = '$arrData[50]'                                   , ".
                                "Card_1st_LAU       = '$arrData[51]'                                   , ".
                                "Card_1st_City      = '$arrData[52]'                                   , ".
                                "Card_1st_Postal    = '$arrData[53]'                                   , ".
                                "Card_1st_State     = '$arrData[54]'                                   , ".
                                "Card_1st_Phone     = '$arrData[55]'                                   , ".
                                "Card_2nd_Family    = '$arrData[69]'                                   , ".
                                "Card_2nd_Address   = '$arrData[70]'                                   , ".
                                "Card_2nd_LAU       = '$arrData[71]'                                   , ".
                                "Card_2nd_City      = '$arrData[72]'                                   , ".
                                "Card_2nd_Postal    = '$arrData[73]'                                   , ".
                                "Card_2nd_State     = '$arrData[74]'                                   , ".
                                "Card_2nd_Phone     = '$arrData[75]'                                   , ".
                                "Card_3rd_Spouse    = '$arrData[56]'                                   , ".
                                "Card_3rd_Birth     = '$arrData[57]'                                   , ".
                                "Card_3rd_Date      = '$arrData[60]-$arrData[59]-$arrData[58] 00:00:00', ".
                                "Card_3rd_Job       = '$arrData[61]'                                   , ".
                                "Card_3rd_Corporate = '$arrData[62]'                                   , ".
                                "Card_3rd_Address   = '$arrData[63]'                                   , ".
                                "Card_3rd_LAU       = '$arrData[64]'                                   , ".
                                "Card_3rd_City      = '$arrData[65]'                                   , ".
                                "Card_3rd_Postal    = '$arrData[66]'                                   , ".
                                "Card_3rd_State     = '$arrData[67]'                                   , ".
                                "Card_3rd_Phone     = '$arrData[68]'                                   , ".
                                "Card_Register      = '$arrData[87]'                                   , ".
                                "Card_Company       = '$arrData[88]'                                   , ".
                                "Card_Branch        = '$arrData[89]'                                   , ".
                                "Card_Title         = '$arrData[90]'                                   , ".
                                "Card_Contract      = '$arrData[91]'                                   , ".
                                "Card_Wages         = '$arrData[92]'                                   , ".
                                "Card_AC            = '$arrData[95]'                                   , ".
                                "Card_AN            = '$arrData[96]'                                   , ".
                                "Card_Bank          = '$arrData[94]'                                   , ".
                                "Card_Picture       = '$arrData[23]'                                   , ".
                                "Card_Paid          = '$arrData[93]'                                   , ".
                                "Card_Docs_01       = '$arrData[76]'                                   , ".
                                "Card_Docs_02       = '$arrData[77]'                                   , ".
                                "Card_Docs_03       = '$arrData[78]'                                   , ".
                                "Card_Docs_04       = '$arrData[79]'                                   , ".
                                "Card_Docs_05       = '$arrData[80]'                                   , ".
                                "Card_Docs_06       = '$arrData[81]'                                   , ".
                                "Card_Docs_07       = '$arrData[82]'                                   , ".
                                "Card_Docs_08       = '$arrData[83]'                                   , ".
                                "Card_Docs_09       = '$arrData[84]'                                   , ".
                                "Card_Docs_10       = '$arrData[86]'                                   , ".
                                "Card_1st_User      = '$strUserName'                                   , ".
                                "Card_1st_Date      =  now()                                           , ".
                                "Card_2nd_User      = '$strUserName'                                   , ".
                                "Card_2nd_Date      =  now()                                             ";
         }
         
         $rsInput      = mysql_query($qrInput);
         
         if($_FILES['23']['name'])
         {
            $intSize   = 150;
            $objUpload = $_FILES['23']['tmp_name'];
            $objName   = $_FILES['23']['name'];
            
            list($objWidth, $objHeight, $objFormat) = getize($objUpload);
            
            $intWidth  = $objWidth > $intSize ? $intSize                            : $objWidth;
            $intHeight = $objWidth > $intSize ? ($objHeight / $objWidth) * $intSize : $objHeight;
            
            switch($objFormat)
            {
               case 1  : $objImage = imagecreatefromgif ($objUpload);
                         break;
               case 2  : $objImage = imagecreatefromjpeg($objUpload);
                         break;
               case 3  : $objImage = imagecreatefrompng ($objUpload);
                         break;
            }
            
            $objCreate = imagecreatetruecolor($intWidth, $intHeight);
            
            if($objFormat != 2)
            {
               imagealphablending($objCreate, false); avealpha($objCreate, true);
               
               $objColor   = imagecolorallocatealpha($objCreate, 255, 255, 255, 127);
               
               imagefilledrectangle($objCreate, 0, 0, $intWidth, $intHeight, $objColor);
            }
            
            imagecopyresampled($objCreate, $objImage, 0, 0, 0, 0, $intWidth, $intHeight, $objWidth, $objHeight);
            
            switch($objFormat)
            {
               case 1  : imagegif ($objCreate, $arrData[23]);
                         break;
               case 2  : imagejpeg($objCreate, $arrData[23], 100);
                         break;
               case 3  : imagepng ($objCreate, $arrData[23], 0);
                         break;
            }
            
            imagedestroy($objCreate);
            imagedestroy($objImage);
         }
         
         switch($strVariable)
         {
            case "RG"  : header("Location:lookup_registrar.php?$strObject");
                         break;
            case "EM"  : header("Location:lookup_resources.php?$strObject");
                         break;
            case "RS"  : header("Location:lookup_resources.php?$strObject");
                         break;
         }
      }
      
      $arrData[0]      = stripslashes($_POST['00']);
      $arrData[1]      = stripslashes($_POST['01']);
      $arrData[2]      = stripslashes($_POST['02']);
      $arrData[3]      = stripslashes($_POST['03']);
      $arrData[4]      = stripslashes($_POST['04']);
      $arrData[5]      = stripslashes($_POST['05']);
      $arrData[6]      = stripslashes($_POST['06']);
      $arrData[7]      = stripslashes($_POST['07']);
      $arrData[8]      = stripslashes($_POST['08']);
      $arrData[9]      = stripslashes($_POST['09']);
      $arrData[10]     = stripslashes($_POST['10']);
      $arrData[11]     = stripslashes($_POST['11']);
      $arrData[12]     = stripslashes($_POST['12']);
      $arrData[13]     = stripslashes($_POST['13']);
      $arrData[14]     = stripslashes($_POST['14']);
      $arrData[15]     = stripslashes($_POST['15']);
      $arrData[16]     = stripslashes($_POST['16']);
      $arrData[17]     = stripslashes($_POST['17']);
      $arrData[18]     = stripslashes($_POST['18']);
      $arrData[19]     = stripslashes($_POST['19']);
      $arrData[20]     = stripslashes($_POST['20']);
      $arrData[21]     = stripslashes($_POST['21']);
      $arrData[22]     = stripslashes($_POST['22']);
   /* $arrData[23]     = stripslashes($_POST['23']); */
      $arrData[24]     = stripslashes($_POST['24']);
      $arrData[25]     = stripslashes($_POST['25']);
      $arrData[26]     = stripslashes($_POST['26']);
      $arrData[27]     = stripslashes($_POST['27']);
      $arrData[28]     = stripslashes($_POST['28']);
      $arrData[29]     = stripslashes($_POST['29']);
      $arrData[30]     = stripslashes($_POST['30']);
      $arrData[31]     = stripslashes($_POST['31']);
      $arrData[32]     = stripslashes($_POST['32']);
      $arrData[33]     = stripslashes($_POST['33']);
      $arrData[34]     = stripslashes($_POST['34']);
      $arrData[35]     = stripslashes($_POST['35']);
      $arrData[36]     = stripslashes($_POST['36']);
      $arrData[37]     = stripslashes($_POST['37']);
      $arrData[38]     = stripslashes($_POST['38']);
      $arrData[39]     = stripslashes($_POST['39']);
      $arrData[40]     = stripslashes($_POST['40']);
      $arrData[41]     = stripslashes($_POST['41']);
      $arrData[42]     = stripslashes($_POST['42']);
      $arrData[43]     = stripslashes($_POST['43']);
      $arrData[44]     = stripslashes($_POST['44']);
      $arrData[45]     = stripslashes($_POST['45']);
      $arrData[46]     = stripslashes($_POST['46']);
      $arrData[47]     = stripslashes($_POST['47']);
      $arrData[48]     = stripslashes($_POST['48']);
      $arrData[49]     = stripslashes($_POST['49']);
      $arrData[50]     = stripslashes($_POST['50']);
      $arrData[51]     = stripslashes($_POST['51']);
      $arrData[52]     = stripslashes($_POST['52']);
      $arrData[53]     = stripslashes($_POST['53']);
      $arrData[54]     = stripslashes($_POST['54']);
      $arrData[55]     = stripslashes($_POST['55']);
      $arrData[56]     = stripslashes($_POST['56']);
      $arrData[57]     = stripslashes($_POST['57']);
      $arrData[58]     = stripslashes($_POST['58']);
      $arrData[59]     = stripslashes($_POST['59']);
      $arrData[60]     = stripslashes($_POST['60']);
      $arrData[61]     = stripslashes($_POST['61']);
      $arrData[62]     = stripslashes($_POST['62']);
      $arrData[63]     = stripslashes($_POST['63']);
      $arrData[64]     = stripslashes($_POST['64']);
      $arrData[65]     = stripslashes($_POST['65']);
      $arrData[66]     = stripslashes($_POST['66']);
      $arrData[67]     = stripslashes($_POST['67']);
      $arrData[68]     = stripslashes($_POST['68']);
      $arrData[69]     = stripslashes($_POST['69']);
      $arrData[70]     = stripslashes($_POST['70']);
      $arrData[71]     = stripslashes($_POST['71']);
      $arrData[72]     = stripslashes($_POST['72']);
      $arrData[73]     = stripslashes($_POST['73']);
      $arrData[74]     = stripslashes($_POST['74']);
      $arrData[75]     = stripslashes($_POST['75']);
      $arrData[76]     =   RenBoolean($_POST['76']);
      $arrData[77]     =   RenBoolean($_POST['77']);
      $arrData[78]     =   RenBoolean($_POST['78']);
      $arrData[79]     =   RenBoolean($_POST['79']);
      $arrData[80]     =   RenBoolean($_POST['80']);
      $arrData[81]     =   RenBoolean($_POST['81']);
      $arrData[82]     =   RenBoolean($_POST['82']);
      $arrData[83]     =   RenBoolean($_POST['83']);
      $arrData[84]     =   RenBoolean($_POST['84']);
      $arrData[85]     =   RenBoolean($_POST['85']);
      $arrData[86]     = stripslashes($_POST['86']);
      $arrData[87]     = stripslashes($_POST['87']);
      $arrData[88]     = stripslashes($_POST['88']);
      $arrData[89]     = stripslashes($_POST['89']);
      $arrData[90]     = stripslashes($_POST['90']);
      $arrData[91]     = stripslashes($_POST['91']);
      $arrData[92]     = stripslashes($_POST['92']);
      $arrData[93]     =   RenBoolean($_POST['93']);
      $arrData[94]     = stripslashes($_POST['94']);
      $arrData[95]     = stripslashes($_POST['95']);
      $arrData[96]     = stripslashes($_POST['96']);
      $arrData[97]     = stripslashes($_POST['97']);
      $arrData[98]     =   RenBoolean($_POST['98']);
      $arrData[99]     = stripslashes($_POST['99']);
      $arrData[100]    = stripslashes($_POST['100']);
      $arrData[101]    = stripslashes($_POST['101']);
      $arrData[102]    = stripslashes($_POST['102']);
      $arrData[103]    = stripslashes($_POST['103']);
   }
?>

<html>

<head>
   <meta http-equiv="Content-Language" content="en-us">
   <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
   <meta name="Keywords" content="Bursa Kerja, Career, Calon Karyawan, Cari Kerja, HRD, Human Resources, Indonesia, Interview, Jobs, Job Fair, Job Seeker, Karir, Kinerja, Lowongan, Outsources, Outsourcing, Recruitments, Relasi, Relationships, Resources, SDM, Sumber Daya Manusia, Tenaga Kerja, Wawancara">
   <meta name="Description" content="Indonesia's Best Outsourcing">
   <meta name="Author" content="Exteron Corporation">
   <title>..:: PT Jasmine Indonesia ::..</title>
   <link href="admin/style.css" type="text/css" rel="stylesheet">
</head>

<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" background="admin//back_01.gif">
   <table cellpadding="0" cellspacing="0" border="0" width="100%">
   <tr>
      <td width="100%" background="admin//back_01.gif">
         <div align="center"><center>
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <tr>
            <td width="750" height="100" background="admin//logo.gif"><a href="index.php?ref=&var=RG&obj=<?php echo $strObject ; ?>"></a><a href="index.php?ref=&var=RG&obj=<?php echo $strObject ; ?>"><img
                              src="admin//home.png" width="50" height="50" border="0" align="right"></a></td>
         </tr>
         <tr>
            <td width="750">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width="125" height=" 25" background="<?php echo $strVariable == "admin/RG" ? "/main_11.gif" : "/main_01.gif"; ?>">
                     <p class="main" align="center">
                        <?php
                           switch($strVariable)
                           {
                              case "RG" : echo "<b>JOB SEEKER</b>";
                                          break;
                              case "EM" : if($_SESSION['PERMISSION_01'])
                                          {
                                             echo "<a class=\"main\" href=\"lookup_registrar.php\">JOB SEEKER</a>";
                                          } else {
                                             echo "<b>JOB SEEKER</b>";
                                          }
                                                break;
                              case "RS" : if($_SESSION['PERMISSION_01'])
                                          {
                                             echo "<a class=\"main\" href=\"lookup_registrar.php\">JOB SEEKER</a>";
                                          } else {
                                             echo "<b>JOB SEEKER</b>";
                                          }
                                          break;
                           }
                        ?>
                     </p>
                  </td>
                  <td width="125" height=" 25" background="admin//main_02.gif">
                     <p class="main" align="center">
                        <?php
                           if($_SESSION['PERMISSION_02'])
                           {
                              echo "<a class=\"main\" href=\"lookup_interview.php\">INTERVIEW</a>";
                           } else {
                              echo "<b>INTERVIEW</b>";
                           }
                        ?>
                     </p>
                  </td>
                  <td width="125" height=" 25" background="<?php echo $strVariable == "admin/EM" || $strVariable == "RS" ? "/main_12.gif" : "/main_02.gif"; ?>">
                     <p class="main" align="center">
                        <?php
                           switch($strVariable)
                           {
                              case "RG" : if($_SESSION['PERMISSION_03'])
                                          {
                                             echo "<a class=\"main\" href=\"lookup_resources.php\">EMPLOYEE</a>";
                                          } else {
                                             echo "<b>EMPLOYEE</b>";
                                          }
                                          break;
                              case "EM" : echo "<b>EMPLOYEE</b>";
                                          break;
                              case "RS" : echo "<b>EMPLOYEE</b>";
                                          break;
                           }
                        ?>
                    
                  <td width="125" height=" 25" background="admin//main_02.gif">
                     <p class="main" align="center">
                        <?php
                           if($_SESSION['LEVEL'])
                           {
                              echo "<a class=\"main\" href=\"lookup_account.php\">USER ACCOUNT</a>";
                           } else {
                              echo "<a class=\"main\" href=\"detail_password.php\">SET PASSWORD</a>";
                           }
                        ?>
                     </p>
                  </td>
                  <td width="125" height=" 25" background="admin//main_03.gif">
                     <p class="main" align="center">
                        <a class="main" href="admin/logout.php">LOGOUT</a>
                     </p>
                  </td>
               </tr>
               </table>
            </td>
         </tr>
         </table>
         </center></div>
      </td>
   </tr>
   <tr>
      <td width="100%" background="admin//back_02.gif">
         <div align="center"><center>
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <tr>
            <td width="750" background="admin//back_04.gif">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <form name="form" method="post" enctype="multipart/form-data">
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <?php
                  if($strError)
                  {
               ?>
               <tr>
                  <td width="750" height=" 20">
                     <p class="form" align="left"><?php echo $strError; ?></p>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <?php
                  }
               ?>
               <tr>
                  <td width="750" height=" 60" background="admin//menu_09.gif"></td>
               </tr>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <tr>
                        <td width="600" valign="top">
                           <table cellpadding="0" cellspacing="0" border="0" width="600">
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">No. Dokumen</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <input class="hide" type="text" name="00" size="20" maxlength="20" value="<?php echo $arrData[0]; ?>" readonly>
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">Nama Lengkap (sesuai KTP)</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <input class="form" type="text" name="01" size="59" maxlength="50" value="<?php echo $arrData[1]; ?>">
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">Tempat dan Tanggal Lahir</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <input class="form" type="text" name="02" size="20" maxlength="50" value="<?php echo $arrData[2]; ?>">
                                    <select size="1" name="03">
                                       <?php
                                          for($intCount  = 1; $intCount <= 31; $intCount++)
                                          {
                                             echo "<option value=\"". substr("00". $intCount, -2)  ."\" ";
                                             echo $arrData[3]  ==     substr("00". $intCount, -2) ? "selected" : "";
                                             echo ">".                substr("00". $intCount, -2)  ."</option>";
                                          }
                                       ?>
                                    </select>
                                    <select size="1" name="04">
                                       <?php
                                          for($intCount  = 1; $intCount <= count($arrMonth); $intCount++)
                                          {
                                             echo "<option value=\"". substr("00". $intCount, -2)  ."\" ";
                                             echo $arrData[4]  ==     substr("00". $intCount, -2) ? "selected" : "";
                                             echo ">".                $arrMonth[$intCount]         ."</option>";
                                          }
                                       ?>
                                    </select>
                                    <select size="1" name="05">
                                       <?php
                                          for($intCount  = 1950; $intCount <= date("Y"); $intCount++)
                                          {
                                             echo "<option value=\"". substr("0000". $intCount, -4)  ."\" ";
                                             echo $arrData[5]  ==     substr("0000". $intCount, -4) ? "selected" : "";
                                             echo ">".                substr("0000". $intCount, -4)  ."</option>";
                                          }
                                       ?>
                                    </select>
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">No. KTP</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <input class="form" type="text" name="06" size="20" maxlength="20" value="<?php echo $arrData[6]; ?>">
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">Jenis Kelamin</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <select class="form" size="1" name="07">
                                       <?php
                                          for($intCount  = 1; $intCount <= count($arrGender); $intCount++)
                                          {
                                             echo "<option value=\"". $arrGender[$intCount]  ."\" ";
                                             echo $arrData[7]  ==     $arrGender[$intCount] ? "selected" : "";
                                             echo ">".                $arrGender[$intCount]  ."</option>";
                                          }
                                       ?>
                                    </select>
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">Agama</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <select class="form" size="1" name="08">
                                       <?php
                                          for($intCount  = 1; $intCount <= count($arrReligion); $intCount++)
                                          {
                                             echo "<option value=\"". $arrReligion[$intCount]  ."\" ";
                                             echo $arrData[8]  ==     $arrReligion[$intCount] ? "selected" : "";
                                             echo ">".                $arrReligion[$intCount]  ."</option>";
                                          }
                                       ?>
                                    </select>
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">Status Perkawinan</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <select class="form" size="1" name="09">
                                       <?php
                                          for($intCount  = 1; $intCount <= count($arrRelation); $intCount++)
                                          {
                                             echo "<option value=\"". $arrRelation[$intCount]  ."\" ";
                                             echo $arrData[9]  ==     $arrRelation[$intCount] ? "selected" : "";
                                             echo ">".                $arrRelation[$intCount]  ."</option>";
                                          }
                                       ?>
                                    </select>
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">Jumlah Anak (bila ada)</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <input class="form" type="text" name="10" size="5" maxlength="5" value="<?php echo $arrData[10]; ?>">
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">Alamat</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <textarea name="11" rows="3" cols="61"><?php echo $arrData[11]; ?></textarea>
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">RT / RW</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <input class="form" type="text" name="12" size="59" maxlength="50" value="<?php echo $arrData[12]; ?>">
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">Kota</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <select class="form" size="1" name="13">
                                       <?php
                                          for($intCount  = 1; $intCount <= count($arrCity); $intCount++)
                                          {
                                             echo "<option value=\"". $arrCity[$intCount]  ."\" ";
                                             echo $arrData[13] ==     $arrCity[$intCount] ? "selected" : "";
                                             echo ">".                $arrCity[$intCount]  ."</option>";
                                          }
                                       ?>
                                    </select>
                                  ��Kode Pos
                    ����������������<input class="form" type="text" name="14" size="10" maxlength="10" value="<?php echo $arrData[14]; ?>">
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">Propinsi</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <select class="form" size="1" name="15">
                                       <?php
                                          for($intCount  = 1; $intCount <= count($arrState); $intCount++)
                                          {
                                             echo "<option value=\"". $arrState[$intCount]  ."\" ";
                                             echo $arrData[15] ==     $arrState[$intCount] ? "selected" : "";
                                             echo ">".                $arrState[$intCount]  ."</option>";
                                          }
                                       ?>
                                    </select>
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">No. Telp</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <input class="form" type="text" name="16" size="20" maxlength="20" value="<?php echo $arrData[16]; ?>">
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">No. Ponsel</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <input class="form" type="text" name="17" size="20" maxlength="20" value="<?php echo $arrData[17]; ?>">
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">Email</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <input class="form" type="text" name="18" size="59" maxlength="250" value="<?php echo $arrData[18]; ?>">
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">Status Tempat Tinggal</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <select class="form" size="1" name="19">
                                       <?php
                                          for($intCount  = 1; $intCount <= count($arrHouse); $intCount++)
                                          {
                                             echo "<option value=\"". $arrHouse[$intCount]  ."\" ";
                                             echo $arrData[19] ==     $arrHouse[$intCount] ? "selected" : "";
                                             echo ">".                $arrHouse[$intCount]  ."</option>";
                                          }
                                       ?>
                                    </select>
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">Status Kendaraan</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <select class="form" size="1" name="20">
                                       <?php
                                          for($intCount  = 1; $intCount <= count($arrVehicle); $intCount++)
                                          {
                                             echo "<option value=\"". $arrVehicle[$intCount]  ."\" ";
                                             echo $arrData[20] ==     $arrVehicle[$intCount] ? "selected" : "";
                                             echo ">".                $arrVehicle[$intCount]  ."</option>";
                                          }
                                       ?>
                                    </select>
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">Minat Terhadap Pekerjaan</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <select class="form" size="1" name="21">
                                       <?php
                                          for($intCount  = 1; $intCount <= count($arrTitle); $intCount++)
                                          {
                                             echo "<option value=\"". $arrTitle[$intCount]  ."\" ";
                                             echo $arrData[21] ==     $arrTitle[$intCount] ? "selected" : "";
                                             echo ">".                $arrTitle[$intCount]  ."</option>";
                                          }
                                       ?>
                                    </select>
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="200" height="25">
                                 <p align="left">Mengetahui Kami Dari</p>
                              </td>
                              <td width="400" height="25">
                                 <p align="left">
                                    <select class="form" size="1" name="22">
                                       <?php
                                          for($intCount  = 1; $intCount <= count($arrAdvertize); $intCount++)
                                          {
                                             echo "<option value=\"". $arrAdvertize[$intCount]  ."\" ";
                                             echo $arrData[22] ==     $arrAdvertize[$intCount] ? "selected" : "";
                                             echo ">".                $arrAdvertize[$intCount]  ."</option>";
                                          }
                                       ?>
                                    </select>
                                 </p>
                              </td>
                           </tr>
                           </table>
                        </td>
                        <td width="150" valign="top">
                           <table cellpadding="0" cellspacing="0" border="0" width="150">
                           <tr>
                              <td width="150" height=" 25">
                                 <p align="center">
                                    <?php
                                       if($arrData[23] == "")
                                       {
                                          $arrData[23]  = "/noname.gif";
                                       } else {
                                          $arrData[23]  = file_exists($arrData[23]) ? $arrData[23] : "images/noname.gif";
                                       }
                                       
                                       list($objWidth, $objHeight, $objFormat) = getimagesize($arrData[23]);
                                       
                                       echo "<img src=\"$arrData[23]\" name=\"img\" width=\"$objWidth\" height=\"$objHeight\" border=\"0\">";
                                    ?>
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="150" height=" 25">
                                 <p align="center">
                                    <input class="form" type="file" name="23" size="10" maxlength="250" onChange="JavaScript:OpenImage('img')">
                                 </p>
                              </td>
                           </tr>
                           </table>
                        </td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750" height=" 60" background="admin/images/menu_10.gif"></td>
               </tr>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <tr>
                        <td width="750" height=" 30" background="admin/images/menu_05.gif">
                           <table cellpadding="0" cellspacing="0" border="0" width="750">
                           <tr>
                              <td width="285"><p class="menu" align="center">SMU / Perguruan Tinggi</p></td>
                              <td width="285"><p class="menu" align="center">Jurusan</p></td>
                              <td width=" 90"><p class="menu" align="center">Thn Lulus</p></td>
                              <td width=" 90"><p class="menu" align="center">IPK</p></td>
                           </tr>
                           </table>
                        </td>
                     </tr>
                     <tr>
                        <td width="750" height="10"></td>
                     </tr>
                     <tr>
                        <td width="750">
                           <table cellpadding="0" cellspacing="0" border="0" width="750">
                           <tr>
                              <td width="430" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="24" size="78" maxlength="50" value="<?php echo $arrData[24]; ?>">
                                 </p>
                              </td>
                              <td width="140" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="25" size="20" maxlength="20" value="<?php echo $arrData[25]; ?>">
                                 </p>
                              </td>
                              <td width=" 90" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="26" size="10" maxlength="10" value="<?php echo $arrData[26]; ?>">
                                 </p>
                              </td>
                              <td width=" 90" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="27" size="10" maxlength="10" value="<?php echo $arrData[27]; ?>">
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="430" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="28" size="78" maxlength="50" value="<?php echo $arrData[28]; ?>">
                                 </p>
                              </td>
                              <td width="140" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="29" size="20" maxlength="20" value="<?php echo $arrData[29]; ?>">
                                 </p>
                              </td>
                              <td width=" 90" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="30" size="10" maxlength="10" value="<?php echo $arrData[30]; ?>">
                                 </p>
                              </td>
                              <td width=" 90" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="31" size="10" maxlength="10" value="<?php echo $arrData[31]; ?>">
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="430" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="32" size="78" maxlength="50" value="<?php echo $arrData[32]; ?>">
                                 </p>
                              </td>
                              <td width="140" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="33" size="20" maxlength="20" value="<?php echo $arrData[33]; ?>">
                                 </p>
                              </td>
                              <td width=" 90" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="34" size="10" maxlength="10" value="<?php echo $arrData[34]; ?>">
                                 </p>
                              </td>
                              <td width=" 90" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="35" size="10" maxlength="10" value="<?php echo $arrData[35]; ?>">
                                 </p>
                              </td>
                           </tr>
                           </table>
                        </td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750" height=" 60" background="admin/images/menu_11.gif"></td>
               </tr>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <tr>
                        <td width="750" height=" 30" background="admin/images/menu_06.gif">
                           <table cellpadding="0" cellspacing="0" border="0" width="750">
                           <tr>
                              <td width="250"><p class="menu" align="center">Perusahaan</p></td>
                              <td width="250"><p class="menu" align="center">Jenis Usaha</p></td>
                              <td width="125"><p class="menu" align="center">Jabatan</p></td>
                              <td width="125"><p class="menu" align="center">Periode</p></td>
                           </tr>
                           </table>
                        </td>
                     </tr>
                     <tr>
                        <td width="750" height="10"></td>
                     </tr>
                     <tr>
                        <td width="750">
                           <table cellpadding="0" cellspacing="0" border="0" width="750">
                           <tr>
                              <td width="330" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="36" size="58" maxlength="50" value="<?php echo $arrData[36]; ?>">
                                 </p>
                              </td>
                              <td width="140" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="37" size="20" maxlength="20" value="<?php echo $arrData[37]; ?>">
                                 </p>
                              </td>
                              <td width="140" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="38" size="20" maxlength="20" value="<?php echo $arrData[38]; ?>">
                                 </p>
                              </td>
                              <td width="140" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="39" size="20" maxlength="20" value="<?php echo $arrData[39]; ?>">
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="330" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="40" size="58" maxlength="50" value="<?php echo $arrData[40]; ?>">
                                 </p>
                              </td>
                              <td width="140" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="41" size="20" maxlength="20" value="<?php echo $arrData[41]; ?>">
                                 </p>
                              </td>
                              <td width="140" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="42" size="20" maxlength="20" value="<?php echo $arrData[42]; ?>">
                                 </p>
                              </td>
                              <td width="140" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="43" size="20" maxlength="20" value="<?php echo $arrData[43]; ?>">
                                 </p>
                              </td>
                           </tr>
                           <tr>
                              <td width="330" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="44" size="58" maxlength="50" value="<?php echo $arrData[44]; ?>">
                                 </p>
                              </td>
                              <td width="140" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="45" size="20" maxlength="20" value="<?php echo $arrData[45]; ?>">
                                 </p>
                              </td>
                              <td width="140" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="46" size="20" maxlength="20" value="<?php echo $arrData[46]; ?>">
                                 </p>
                              </td>
                              <td width="140" height="25">
                                 <p align="center">
                                    <input class="form" type="text" name="47" size="20" maxlength="20" value="<?php echo $arrData[47]; ?>">
                                 </p>
                              </td>
                           </tr>
                           </table>
                        </td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750" height=" 60" background="admin/images/menu_12.gif"></td>
               </tr>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Nama Ayah Kandung</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="48" size="59" maxlength="50" value="<?php echo $arrData[48]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Nama Ibu Kandung</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="49" size="59" maxlength="50" value="<?php echo $arrData[49]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Alamat Orang Tua</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <textarea name="50" rows="3" cols="61"><?php echo $arrData[50]; ?></textarea>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">RT / RW</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="51" size="59" maxlength="50" value="<?php echo $arrData[51]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Kota</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <select class="form" size="1" name="52">
                                 <?php
                                    for($intCount  = 1; $intCount <= count($arrCity); $intCount++)
                                    {
                                       echo "<option value=\"". $arrCity[$intCount]  ."\" ";
                                       echo $arrData[52] ==     $arrCity[$intCount] ? "selected" : "";
                                       echo ">".                $arrCity[$intCount]  ."</option>";
                                    }
                                 ?>
                              </select>
                            ��Kode Pos
              ����������������<input class="form" type="text" name="53" size="10" maxlength="10" value="<?php echo $arrData[53]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Propinsi</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <select class="form" size="1" name="54">
                                 <?php
                                    for($intCount  = 1; $intCount <= count($arrState); $intCount++)
                                    {
                                       echo "<option value=\"". $arrState[$intCount]  ."\" ";
                                       echo $arrData[54] ==     $arrState[$intCount] ? "selected" : "";
                                       echo ">".                $arrState[$intCount]  ."</option>";
                                    }
                                 ?>
                              </select>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">No. Telp</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="55" size="20" maxlength="20" value="<?php echo $arrData[55]; ?>">
                           </p>
                        </td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750" height=" 80" background="admin/images/menu_13.gif"></td>
               </tr>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Nama Pasangan</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="56" size="59" maxlength="50" value="<?php echo $arrData[56]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Tempat dan Tanggal Lahir</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="57" size="20" maxlength="50" value="<?php echo $arrData[57]; ?>">
                              <select size="1" name="58">
                                 <?php
                                    for($intCount  = 1; $intCount <= 31; $intCount++)
                                    {
                                       echo "<option value=\"". substr("00". $intCount, -2)  ."\" ";
                                       echo $arrData[58] ==     substr("00". $intCount, -2) ? "selected" : "";
                                       echo ">".                substr("00". $intCount, -2)  ."</option>";
                                    }
                                 ?>
                              </select>
                              <select size="1" name="59">
                                 <?php
                                    for($intCount  = 1; $intCount <= count($arrMonth); $intCount++)
                                    {
                                       echo "<option value=\"". substr("00". $intCount, -2)  ."\" ";
                                       echo $arrData[59] ==     substr("00". $intCount, -2) ? "selected" : "";
                                       echo ">".                $arrMonth[$intCount]         ."</option>";
                                    }
                                 ?>
                              </select>
                              <select size="1" name="60">
                                 <?php
                                    for($intCount  = 1950; $intCount <= date("Y"); $intCount++)
                                    {
                                       echo "<option value=\"". substr("0000". $intCount, -4)  ."\" ";
                                       echo $arrData[60] ==     substr("0000". $intCount, -4) ? "selected" : "";
                                       echo ">".                substr("0000". $intCount, -4)  ."</option>";
                                    }
                                 ?>
                              </select>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Pekerjaan / Jabatan</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="61" size="20" maxlength="20" value="<?php echo $arrData[61]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Perusahaan</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="62" size="59" maxlength="50" value="<?php echo $arrData[62]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Alamat Perusahaan</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <textarea name="63" rows="3" cols="61"><?php echo $arrData[63]; ?></textarea>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">RT / RW</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="64" size="59" maxlength="50" value="<?php echo $arrData[64]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Kota</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <select class="form" size="1" name="65">
                                 <?php
                                    for($intCount  = 1; $intCount <= count($arrCity); $intCount++)
                                    {
                                       echo "<option value=\"". $arrCity[$intCount]  ."\" ";
                                       echo $arrData[65] ==     $arrCity[$intCount] ? "selected" : "";
                                       echo ">".                $arrCity[$intCount]  ."</option>";
                                    }
                                 ?>
                              </select>
                            ��Kode Pos
              ����������������<input class="form" type="text" name="66" size="10" maxlength="10" value="<?php echo $arrData[66]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Propinsi</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <select class="form" size="1" name="67">
                                 <?php
                                    for($intCount  = 1; $intCount <= count($arrState); $intCount++)
                                    {
                                       echo "<option value=\"". $arrState[$intCount]  ."\" ";
                                       echo $arrData[67] ==     $arrState[$intCount] ? "selected" : "";
                                       echo ">".                $arrState[$intCount]  ."</option>";
                                    }
                                 ?>
                              </select>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">No. Telp</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="68" size="20" maxlength="20" value="<?php echo $arrData[68]; ?>">
                           </p>
                        </td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750" height=" 80" background="admin/images/menu_14.gif"></td>
               </tr>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Nama</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="69" size="59" maxlength="50" value="<?php echo $arrData[69]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Alamat</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <textarea name="70" rows="3" cols="61"><?php echo $arrData[70]; ?></textarea>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">RT / RW</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="71" size="59" maxlength="50" value="<?php echo $arrData[71]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Kota</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <select class="form" size="1" name="72">
                                 <?php
                                    for($intCount  = 1; $intCount <= count($arrCity); $intCount++)
                                    {
                                       echo "<option value=\"". $arrCity[$intCount]  ."\" ";
                                       echo $arrData[72] ==     $arrCity[$intCount] ? "selected" : "";
                                       echo ">".                $arrCity[$intCount]  ."</option>";
                                    }
                                 ?>
                              </select>
                            ��Kode Pos
              ����������������<input class="form" type="text" name="73" size="10" maxlength="10" value="<?php echo $arrData[73]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Propinsi</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <select class="form" size="1" name="74">
                                 <?php
                                    for($intCount  = 1; $intCount <= count($arrState); $intCount++)
                                    {
                                       echo "<option value=\"". $arrState[$intCount]  ."\" ";
                                       echo $arrData[74] ==     $arrState[$intCount] ? "selected" : "";
                                       echo ">".                $arrState[$intCount]  ."</option>";
                                    }
                                 ?>
                              </select>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">No. Telp</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="75" size="20" maxlength="20" value="<?php echo $arrData[75]; ?>">
                           </p>
                        </td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750" height=" 60" background="admin/images/menu_15.gif"></td>
               </tr>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <tr>
                        <td width="200" height="25">
                           <p align="left">
                              <input type="checkbox" name="76" <?php echo $arrData[76] == 1 ? "checked" : ""; ?>>Surat Lamaran Kerja</input>
                           </p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input type="checkbox" name="77" <?php echo $arrData[77] == 1 ? "checked" : ""; ?>>Daftar Riwayat Hidup</input>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">
                              <input type="checkbox" name="78" <?php echo $arrData[78] == 1 ? "checked" : ""; ?>>Surat Referensi Kerja</input>
                           </p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input type="checkbox" name="79" <?php echo $arrData[79] == 1 ? "checked" : ""; ?>>Surat Keterangan Kelakuan Baik</input>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">
                              <input type="checkbox" name="80" <?php echo $arrData[80] == 1 ? "checked" : ""; ?>>Foto Copy KTP</input>
                           </p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input type="checkbox" name="81" <?php echo $arrData[81] == 1 ? "checked" : ""; ?>>Foto Copy SIM A / B / C</input>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">
                              <input type="checkbox" name="82" <?php echo $arrData[82] == 1 ? "checked" : ""; ?>>Foto Copy Ijazah SMU</input>
                           </p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input type="checkbox" name="83" <?php echo $arrData[83] == 1 ? "checked" : ""; ?>>Foto Copy Ijazah Perguruan Tinggi</input>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">
                              <input type="checkbox" name="84" <?php echo $arrData[84] == 1 ? "checked" : ""; ?>>Foto Copy Ijazah Kursus</input>
                           </p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input type="checkbox" name="85" <?php echo $arrData[85] == 1 ? "checked" : ""; ?>>Lainnya, sebutkan :</input>
                              <input class="form" type="text" name="86" size="32" maxlength="50" value="<?php echo $arrData[86]; ?>">
                           </p>
                        </td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <?php
                  if($strVariable == "EM" || $strVariable == "RS")
                  {
               ?>
               <tr>
                  <td width="750" height=" 60" background="admin/images/menu_16.gif"></td>
               </tr>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <tr>
                        <td width="200" height="25">
                           <p align="left">No. Induk Karyawan</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="87" size="20" maxlength="20" value="<?php echo $arrData[87]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Klien</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <select class="form" size="1" name="88">
                                 <?php
                                    for($intCount  = 1; $intCount <= count($arrCompany); $intCount++)
                                    {
                                       echo "<option value=\"". $arrCompany[$intCount]  ."\" ";
                                       echo $arrData[88] ==     $arrCompany[$intCount] ? "selected" : "";
                                       echo ">".                $arrCompany[$intCount]  ."</option>";
                                    }
                                 ?>
                              </select>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Lokasi Penempatan</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="89" size="59" maxlength="50" value="<?php echo $arrData[89]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Jabatan</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <select class="form" size="1" name="90">
                                 <?php
                                    for($intCount  = 1; $intCount <= count($arrTitle); $intCount++)
                                    {
                                       echo "<option value=\"". $arrTitle[$intCount]  ."\" ";
                                       echo $arrData[90] ==     $arrTitle[$intCount] ? "selected" : "";
                                       echo ">".                $arrTitle[$intCount]  ."</option>";
                                    }
                                 ?>
                              </select>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Lama Kontrak</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="91" size="5" maxlength="5" value="<?php echo $arrData[91]; ?>">��Bulan
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Upah / Gaji</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="92" size="20" maxlength="20" value="<?php echo $arrData[92]; ?>">
                            ��<input type="checkbox" name="93" <?php echo $arrData[93] == 1 ? "checked" : ""; ?>>Klien Menanggung Upah / Gaji</input>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Nama Bank</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="94" size="59" maxlength="50" value="<?php echo $arrData[94]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">No. Rekening</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="95" size="20" maxlength="20" value="<?php echo $arrData[95]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Atas Nama</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="form" type="text" name="96" size="59" maxlength="50" value="<?php echo $arrData[96]; ?>">
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Status Karyawan</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input type="radio" name="97" value="RG" <?php echo $arrData[97] == "RG" ? "checked" : ""; ?>>Pelamar
                              <input type="radio" name="97" value="EM" <?php echo $arrData[97] == "EM" ? "checked" : ""; ?>>Aktif
                              <input type="radio" name="97" value="RS" <?php echo $arrData[97] == "RS" ? "checked" : ""; ?>>Non-Aktif
                           </p>
                        </td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <?php
                  }
               ?>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <tr>
                        <td width="750" height="25">
                           <p align="left">
                              <input type="checkbox" name="98" <?php echo $arrData[98] == 1 ? "checked" : ""; ?>>Ya, Kirimkan saya</input>
                              <select size="1" name="99">
                                 <?php
                                    for($intCount  = 1; $intCount <= count($arrNewsletter); $intCount++)
                                    {
                                       echo "<option value=\"". $arrNewsletter[$intCount]  ."\" ";
                                       echo $arrData[99] ==     $arrNewsletter[$intCount] ? "selected" : "";
                                       echo ">".                $arrNewsletter[$intCount]  ."</option>";
                                    }
                                 ?>
                              </select>
                              setiap kali ada informasi lowongan pekerjaan
                           </p>
                        </td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750" height=" 60" background="admin/images/menu_17.gif"></td>
               </tr>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Tanggal Pencatatan</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="hide" type="text" name="100" size="20" maxlength="20" value="<?php echo $arrData[100]; ?>" readonly>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Tanggal Wawancara</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="hide" type="text" name="101" size="20" maxlength="20" value="<?php echo $arrData[101]; ?>" readonly>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Tanggal Mulai Bekerja</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="hide" type="text" name="102" size="20" maxlength="20" value="<?php echo $arrData[102]; ?>" readonly>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Pewawancara</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="hide" type="text" name="103" size="59" maxlength="50" value="<?php echo $arrData[103]; ?>" readonly>
                           </p>
                        </td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750">
                     <p align="left">
                        <input type="image" name="104" src="admin/images/button_05.gif" width="90" height="30">
                        <?php
                           switch($strVariable)
                           {
                              case "RG" : echo "<a href=\"lookup_registrar.php?$strObject\">";
                                          break;
                              case "EM" : echo "<a href=\"lookup_resources.php?$strObject\">";
                                          break;
                              case "RS" : echo "<a href=\"lookup_resources.php?$strObject\">";
                                          break;
                           }
                        ?>
                        <img src="admin/images/button_07.gif" width="90" height="30" border="0"></a>
                     </p>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               </table>
            </td>
         </tr>
         </table>
         </center></div>
      </td>
   </tr>
   <tr>
      <td width="100%" background="admin/images/back_01.gif">
         <div align="center"><center>
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <tr>
            <td width="750" background="admin/images/back_03.gif">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750">
                     <p class="foot" align="right">
                        <a class="foot" </a> � 2013 Untuk Skripsi
                     </p>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               </table>
            </td>
         </tr>
         </table>
         </center></div>
      </td>
   </tr>
   </table>
</body>

</html>