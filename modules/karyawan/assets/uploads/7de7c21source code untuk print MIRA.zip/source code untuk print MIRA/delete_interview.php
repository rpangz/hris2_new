<?php ob_start();                     ?>
<?php session_start();                ?>
<?php include "data/condata.php";     ?>
<?php include "modules/function.php"; ?>

<?php
   if(!$_SESSION['LOGIN'])
   {
      header("Location:login.php");
   }
   
   $strReference       = $_GET['ref'];
   $strObject          = str_replace("%", "&", $_GET['obj']);
   
   $qrDelete           = "DELETE FROM Ms_Interview ".
                         "WHERE (Interview_Reference = '$strReference') ".
                                "AND (Interview_Card NOT IN (SELECT Card_Reference FROM Ms_Card WHERE (Card_Type IN ('EM', 'RS')))) ".
                         "ORDER BY Interview_Reference";
   
   $rsDelete           = mysql_query($qrDelete);
   
   header("Location:lookup_interview.php?$strObject");
?>