

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>..:: PT Jasmine Indonesia ::..</title>
<link href="style1.css" rel="stylesheet" type="text/css" />
</head>

<body>

 <div id="topheader">
   <div class="logo"></div>
   <div class="menu_area"><a href="index.php" class="ideas">Home</a> <a href="admin/login.php" class="links">Login</a> <a href="admin/register.php" class="info">Registrasi</a> 
 </div>
 
 </div>
 
</div>
 </div>
<div id="body_area">
  <div class="left">
    <div class="left_menutop"></div>
    <div class="left_menu_area">
      <div align="right"><a href="#" class="left_menu">Home</a><br />
          <a href="#" class="left_menu">About us</a><br />
          <a href="#" class="left_menu">Companies success</a><br />
          <a href="#" class="left_menu">Client testimonials</a><br />
          
           </div>
    </div>
  </div>
          
 <!--Body Content -->
  
  <div class="midarea">  
  <link rel="stylesheet" href="global.css">	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
	<script src="slides.min.jquery.js"></script>
    
    <script>
		$(function(){
			$('#slides').slides({
				preload: true,
				preloadImage: 'img/loading.gif',
				play: 5000,
				pause: 2500,
				hoverPause: true,
				animationStart: function(current){
					$('.caption').animate({
						bottom:-35
					},100);
					if (window.console && console.log) {
						// example return of current slide number
						console.log('animationStart on slide: ', current);
					};
				},
				animationComplete: function(current){
					$('.caption').animate({
						bottom:0
					},200);
					if (window.console && console.log) {
						// example return of current slide number
						console.log('animationComplete on slide: ', current);
					};
				},
				slidesLoaded: function() {
					$('.caption').animate({
						bottom:0
					},200);
				}
			});
		});
	</script>
    <body>
	<div id="container">
		<div id="example">
			
			<div id="slides">
			<div class="slides_container">
            
	<div class="slide">           
	<a href="#" title="PT. Jasmine Indonesia memberikan hadiah kepada karyawan teladan" target="_blank">
	<img src="pub/A001.gif" width="470" height="250" alt="Slide 1"></a>
	<div class="caption" style="bottom:0">
	<p>Bagi-bagi Hadiah Uang Tunai</p>
	</div>
	</div>

	<div class="slide">
	<a href="#" title="PT. Jasmine Indonesia memberikan pelatihan Bersama | Indonesian Motivator" target="_blank">
    <img src="pub/A002.gif" width="470" height="250" alt="Slide 2"></a>
	<div class="caption">
	<p>Pelatihan Bersama "Indonesian Motivator"</p>
	
	</div>
	</div>
    
    <div class="slide">
	<a href="#" title="The Best Performance" target="_blank">
    <img src="pub/A003.gif" width="470" height="250" alt="Slide 2"></a>
	<div class="caption" style="bottom:0">
	<p>The Best Performance</p>
	
	</div>
	</div>
    
    <div class="slide">
	<a href="#" title="Senyum Bersama Direktur" target="_blank">
    <img src="pub/A004.gif" width="470" height="250" alt="Slide 2"></a>
	<div class="caption">
	<p>Senyum Bersama Direktur</p>
    
    </div>
	</div>
	
    <div class="slide">
	<a href="#" title="Inspirasi dari Musik" target="_blank">
    <img src="pub/A005.gif" width="470" height="250" alt="Slide 2"></a>
	<div class="caption">
	<p>Inspirasi dari Musik</p>
    
	</div>
	</div>
	</div>
	<a href="#" class="prev"><img src="img/arrow-prev.png" width="24" height="43" alt="Arrow Prev"></a>
	<a href="#" class="next"><img src="img/arrow-next.png" width="24" height="43" alt="Arrow Next"></a>
	</div>
	<img src="img/example-frame.png" width="470" height="250" alt="Example Frame" id="frame">
    </div>
</div>

  
    
    
    <div class="head"> Peraturan baru hapus outsourcing segera diterbitkan </div>
    <div class="body_textarea">
      <div align="justify">Regulasi baru tentang sistem ketenagakerjaan ini, menurut Cak Imin, sapaan akrab Muhaimin, akan memberikan kepastian hukum dan masa depan para pekerja di tanah air.</div>
    </div>
    <div class="body_textarea">
      <div align="justify">
        <p>"Pengusaha juga tidak perlu khawatir karena aturan baru tersebut tidak akan menutup model sistem pemborongan kerja maupun hubungan kerja langsung melalui perjanjian kerja waktu tertentu," kata Cak Imin usai menggelar dialog dengan buruh Jawa Timur di Hotel Utami, Juanda, Sidoarjo Jawa Timur, Kamis (1/11).</p>
        <p>Untuk itu, lanjut dia, istilah outsourcing, setelah peraturan keluar hendaknya sudah tidak dipakai lagi. "Setelah itu, di Indonesia saya harap sudah tidak kenal lagi dengan istilah outsourcing," ujarnya.
          Lebih jauh lagi, Cak Imin menjelaskan, penyedia jasa (outsourcing) hanya digunakan khusus lima bidang penyedia di antaranya katering, transportasi, keamanan, cleaning service dan jasa penunjang pertambangan.</p>
        <p>"Di luar lima bidang itu, kita memberikan waktu enam bulan hingga satu tahun bagi perusahaan outsourcing untuk menghentikan kegiatannya. Setelah waktu itu, tidak ada lagi penyedia outsourcing lagi di Indonesia," kata Cak Imin.
          Namun, jika peringatan ini tidak diindahkan, Cak Imin menegaskan, akan dilakukan tindakan tegas terhadap perusahaan penyedia jasa pekerja yang tetap membandel tersebut.
  "Kita akan memberi sanksi administrasi bahkan hingga pencabutan izin. Untuk sanksi pidana, masih akan diatur dalam undang-undang yang lain," pungkas dia.
          Sumber :Merdeka
          Tags :Berita Nasioanl</p>
      </div>
    </div>
    <div class="body_textarea">
     
    </div>
    <div class="innerbanner"><span class="innerbanner_head">Hidup Untuk Bekerja vs Bekerja Untuk Hidup </span><br />
      <span class="innerbanner_head">Bekerja adalah Impianku</span></div>
  </div>
  <div class="right">
    <div class="comments_area">
      <div class="events_head">Events</div>
      <div class="comments_text">
        <div align="left">On 12th January 2013 <br />
          <a href="#" class="comments_link">Pelatihan Kerja PT.Jasmine Indonesia</a></div>
      </div>
      <div class="comments_text">
        <div align="left">On 14th January 2013 <br />
          <a href="#" class="comments_link">How to increase your's motivation </a></div>
      </div>
      <div class="comments_text">
        <div align="left">On 16th January 2013 <br />
          <a href="#" class="comments_link">Bagaimana Cara Menjadi Karyawan Handal</a></div>
      </div>
    </div>
         
        
    </div>
  </div>
</div>

  
  <div class="fotter_copyrights">
    <div align="center">@2013 Untuk Skripsi</div>
  </div>
 
  </div>
  
</div>


</body>
</html>
