<?php ob_start();                     ?>
<?php session_start();                ?>
<?php include "data/condata.php";     ?>
<?php include "modules/function.php"; ?>
<?php include "modules/function.js";  ?>

<?php
   if(!$_SESSION['LOGIN'])
   {
      header("Location:login.php");
   }
   
   $strUserName        = $_SESSION['LOGIN'];
   $strReference       = $_GET['ref'];
   $strObject          = str_replace("%", "&", $_GET['obj']);
   
   $qrData             = "SELECT Ms_Interview.*, Ms_Card.* ".
                         "FROM  (Ms_Interview LEFT JOIN Ms_Card ON Ms_Interview.Interview_Card = Ms_Card.Card_Reference) ".
                         "WHERE (Ms_Interview.Interview_Reference = '$strReference') ".
                         "ORDER BY Ms_Interview.Interview_Reference";
   
   $rsData             = mysql_query($qrData);
   
   $arrData[0]         = stripslashes("[ Auto Number ]");
   $arrData[1]         = stripslashes(SetCard($strReference, "RF"));
   $arrData[2]         = stripslashes(SetCard($strReference, "NM"));
   $arrData[3]         = stripslashes(date("d"));
   $arrData[4]         = stripslashes(date("m"));
   $arrData[5]         = stripslashes(date("Y"));
   $arrData[19]        = stripslashes("0");
   $arrData[20]        = stripslashes(date("d"));
   $arrData[21]        = stripslashes(date("m"));
   $arrData[22]        = stripslashes(date("Y"));
   $arrData[25]        = stripslashes("RJ");
   
   while($arrFields    = mysql_fetch_array($rsData))
   {
      $arrDate[0]      = explode(" ", $arrFields[2]);
      $arrDate[1]      = explode(" ", $arrFields[3]);
      
      $arrDate[0]      = explode("-", $arrDate[0][0]);
      $arrDate[1]      = explode("-", $arrDate[1][0]);
      
      if(!checkdate($arrDate[1][1], $arrDate[1][2], $arrDate[1][0]))
      {
         $arrDate[1]   = $arrDate[0];
         $arrFields[3] = 0;
      }
      
      $intTotal        =  $arrFields[9] + $arrFields[10] + $arrFields[11] +
                         $arrFields[12] + $arrFields[13] + $arrFields[14] +
                         $arrFields[15] + $arrFields[16] + $arrFields[17] +
                         $arrFields[18];
      
      $arrData[0]      = stripslashes($arrFields[0]);
      $arrData[1]      = stripslashes($arrFields[5]);
      $arrData[2]      = stripslashes($arrFields[25]);
      $arrData[3]      = stripslashes($arrDate[0][2]);
      $arrData[4]      = stripslashes($arrDate[0][1]);
      $arrData[5]      = stripslashes($arrDate[0][0]);
      $arrData[6]      = stripslashes($arrFields[6]);
      $arrData[7]      = stripslashes($arrFields[7]);
      $arrData[8]      = stripslashes($arrFields[8]);
      $arrData[9]      = stripslashes($arrFields[9]);
      $arrData[10]     = stripslashes($arrFields[10]);
      $arrData[11]     = stripslashes($arrFields[11]);
      $arrData[12]     = stripslashes($arrFields[12]);
      $arrData[13]     = stripslashes($arrFields[13]);
      $arrData[14]     = stripslashes($arrFields[14]);
      $arrData[15]     = stripslashes($arrFields[15]);
      $arrData[16]     = stripslashes($arrFields[16]);
      $arrData[17]     = stripslashes($arrFields[17]);
      $arrData[18]     = stripslashes($arrFields[18]);
      $arrData[19]     = stripslashes($intTotal);
      $arrData[20]     = stripslashes($arrDate[1][2]);
      $arrData[21]     = stripslashes($arrDate[1][1]);
      $arrData[22]     = stripslashes($arrDate[1][0]);
      $arrData[23]     =   RenBoolean($arrFields[3]);
      $arrData[24]     = stripslashes($arrFields[4]);
      $arrData[25]     = stripslashes($arrFields[1]);
   }
   
   if($_POST)
   {
      $arrData[0]      = addslashes($_POST['00']);
      $arrData[1]      = addslashes($_POST['01']);
      $arrData[2]      = addslashes($_POST['02']);
      $arrData[3]      = addslashes($_POST['03']);
      $arrData[4]      = addslashes($_POST['04']);
      $arrData[5]      = addslashes($_POST['05']);
      $arrData[6]      = addslashes($_POST['06']);
      $arrData[7]      = addslashes($_POST['07']);
      $arrData[8]      = addslashes($_POST['08']);
      $arrData[9]      = addslashes($_POST['09']);
      $arrData[10]     = addslashes($_POST['10']);
      $arrData[11]     = addslashes($_POST['11']);
      $arrData[12]     = addslashes($_POST['12']);
      $arrData[13]     = addslashes($_POST['13']);
      $arrData[14]     = addslashes($_POST['14']);
      $arrData[15]     = addslashes($_POST['15']);
      $arrData[16]     = addslashes($_POST['16']);
      $arrData[17]     = addslashes($_POST['17']);
      $arrData[18]     = addslashes($_POST['18']);
      $arrData[19]     = addslashes($_POST['19']);
      $arrData[20]     = addslashes($_POST['20']);
      $arrData[21]     = addslashes($_POST['21']);
      $arrData[22]     = addslashes($_POST['22']);
      $arrData[23]     = RenBoolean($_POST['23']);
      $arrData[24]     = addslashes($_POST['24']);
      $arrData[25]     = addslashes($_POST['25']);
      
      if($arrData[1]  == "")
      {
         $strError    .= "Pelamar tidak ada. Isilah Pelamar.<br>";
      }
      
      if(!checkdate($arrData[4], $arrData[3], $arrData[5]))
      {
         $strError    .= "Pilihan Tanggal Wawancara tidak benar. Pastikan Tanggal Wawancara adalah format tanggal.<br>";
      }
      
      if(!checkdate($arrData[21], $arrData[20], $arrData[22]))
      {
         $strError    .= "Pilihan Tanggal Wawancara di Klien tidak benar. Pastikan Tanggal Wawancara di Klien adalah format tanggal.<br>";
      }
      
      if(!$strError)
      {
         $arrData[0]   = SetReference("IN");
         $arrData[20]  = $arrData[23] != 0  ? $arrData[20] : "";
         $arrData[21]  = $arrData[23] != 0  ? $arrData[21] : "";
         $arrData[22]  = $arrData[23] != 0  ? $arrData[22] : "";
         
         if(mysql_num_rows($rsData) > 0)
         {
            $qrInput   = "UPDATE Ms_Interview SET                                                             ".
                                "Interview_Type         = '$arrData[25]'                                    , ".
                                "Interview_Date_1       = '$arrData[5]-$arrData[4]-$arrData[3] 00:00:00'    , ".
                                "Interview_Date_2       = '$arrData[22]-$arrData[21]-$arrData[20] 00:00:00' , ".
                                "Interview_Description  = '$arrData[24]'                                    , ".
                                "Interview_Card         = '$arrData[1]'                                     , ".
                                "Interview_Directed     = '$arrData[6]'                                     , ".
                                "Interview_Company      = '$arrData[7]'                                     , ".
                                "Interview_Title        = '$arrData[8]'                                     , ".
                                "Interview_Appraisal_01 = '$arrData[9]'                                     , ".
                                "Interview_Appraisal_02 = '$arrData[10]'                                    , ".
                                "Interview_Appraisal_03 = '$arrData[11]'                                    , ".
                                "Interview_Appraisal_04 = '$arrData[12]'                                    , ".
                                "Interview_Appraisal_05 = '$arrData[13]'                                    , ".
                                "Interview_Appraisal_06 = '$arrData[14]'                                    , ".
                                "Interview_Appraisal_07 = '$arrData[15]'                                    , ".
                                "Interview_Appraisal_08 = '$arrData[16]'                                    , ".
                                "Interview_Appraisal_09 = '$arrData[17]'                                    , ".
                                "Interview_Appraisal_10 = '$arrData[18]'                                    , ".
                                "Interview_2nd_User     = '$strUserName'                                    , ".
                                "Interview_2nd_Date     =  now()                                              ".
                         "WHERE (Interview_Reference    = '$strReference')                                    ";
         } else {
            $qrInput   = "INSERT INTO Ms_Interview SET                                                        ".
                                "Interview_Reference    = '$arrData[0]'                                     , ".
                                "Interview_Type         = '$arrData[25]'                                    , ".
                                "Interview_Date_1       = '$arrData[5]-$arrData[4]-$arrData[3] 00:00:00'    , ".
                                "Interview_Date_2       = '$arrData[22]-$arrData[21]-$arrData[20] 00:00:00' , ".
                                "Interview_Description  = '$arrData[24]'                                    , ".
                                "Interview_Card         = '$arrData[1]'                                     , ".
                                "Interview_Directed     = '$arrData[6]'                                     , ".
                                "Interview_Company      = '$arrData[7]'                                     , ".
                                "Interview_Title        = '$arrData[8]'                                     , ".
                                "Interview_Appraisal_01 = '$arrData[9]'                                     , ".
                                "Interview_Appraisal_02 = '$arrData[10]'                                    , ".
                                "Interview_Appraisal_03 = '$arrData[11]'                                    , ".
                                "Interview_Appraisal_04 = '$arrData[12]'                                    , ".
                                "Interview_Appraisal_05 = '$arrData[13]'                                    , ".
                                "Interview_Appraisal_06 = '$arrData[14]'                                    , ".
                                "Interview_Appraisal_07 = '$arrData[15]'                                    , ".
                                "Interview_Appraisal_08 = '$arrData[16]'                                    , ".
                                "Interview_Appraisal_09 = '$arrData[17]'                                    , ".
                                "Interview_Appraisal_10 = '$arrData[18]'                                    , ".
                                "Interview_1st_User     = '$strUserName'                                    , ".
                                "Interview_1st_Date     =  now()                                            , ".
                                "Interview_2nd_User     = '$strUserName'                                    , ".
                                "Interview_2nd_Date     =  now()                                              ";
         }
         
         $rsInput      = mysql_query($qrInput);
         
         header("Location:lookup_interview.php?$strObject");
      }
      
      $arrData[0]      = stripslashes($_POST['00']);
      $arrData[1]      = stripslashes($_POST['01']);
      $arrData[2]      = stripslashes($_POST['02']);
      $arrData[3]      = stripslashes($_POST['03']);
      $arrData[4]      = stripslashes($_POST['04']);
      $arrData[5]      = stripslashes($_POST['05']);
      $arrData[6]      = stripslashes($_POST['06']);
      $arrData[7]      = stripslashes($_POST['07']);
      $arrData[8]      = stripslashes($_POST['08']);
      $arrData[9]      = stripslashes($_POST['09']);
      $arrData[10]     = stripslashes($_POST['10']);
      $arrData[11]     = stripslashes($_POST['11']);
      $arrData[12]     = stripslashes($_POST['12']);
      $arrData[13]     = stripslashes($_POST['13']);
      $arrData[14]     = stripslashes($_POST['14']);
      $arrData[15]     = stripslashes($_POST['15']);
      $arrData[16]     = stripslashes($_POST['16']);
      $arrData[17]     = stripslashes($_POST['17']);
      $arrData[18]     = stripslashes($_POST['18']);
      $arrData[19]     = stripslashes($_POST['19']);
      $arrData[20]     = stripslashes($_POST['20']);
      $arrData[21]     = stripslashes($_POST['21']);
      $arrData[22]     = stripslashes($_POST['22']);
      $arrData[23]     =   RenBoolean($_POST['23']);
      $arrData[24]     = stripslashes($_POST['24']);
      $arrData[25]     = stripslashes($_POST['25']);
   }
?>

<html>

<head>
   <meta http-equiv="Content-Language" content="en-us">
   <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
   <meta name="Keywords" content="Bursa Kerja, Career, Calon Karyawan, Cari Kerja, HRD, Human Resources, Indonesia, Interview, Jobs, Job Fair, Job Seeker, Karir, Kinerja, Lowongan, Outsources, Outsourcing, Recruitments, Relasi, Relationships, Resources, SDM, Sumber Daya Manusia, Tenaga Kerja, Wawancara">
   <meta name="Description" content="Indonesia's Best Outsourcing">
   <meta name="Author" content="Exteron Corporation">
   <title>..:: PT Pelangi Fortuna Global - Indonesia's Best Outsourcing ::..</title>
   <link href="style.css" type="text/css" rel="stylesheet">
</head>

<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" background="images/back_01.gif">
   <table cellpadding="0" cellspacing="0" border="0" width="100%">
   <tr>
      <td width="100%" background="images/back_01.gif">
         <div align="center"><center>
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <tr>
            <td width="750" height="100" background="images/logo.gif"></td>
         </tr>
         <tr>
            <td width="750">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width="125" height=" 25" background="images/main_01.gif">
                     <p class="main" align="center">
                        <?php
                           if($_SESSION['PERMISSION_01'])
                           {
                              echo "<a class=\"main\" href=\"lookup_registrar.php\">JOB SEEKER</a>";
                           } else {
                              echo "<b>JOB SEEKER</b>";
                           }
                        ?>
                     </p>
                  </td>
                  <td width="125" height=" 25" background="images/main_12.gif">
                     <p class="main" align="center">
                        <b>INTERVIEW</b>
                     </p>
                  </td>
                  <td width="125" height=" 25" background="images/main_02.gif">
                     <p class="main" align="center">
                        <?php
                           if($_SESSION['PERMISSION_03'])
                           {
                              echo "<a class=\"main\" href=\"lookup_resources.php\">EMPLOYEE</a>";
                           } else {
                              echo "<b>EMPLOYEE</b>";
                           }
                        ?>
                     </p>
                  </td>
                  <td width="125" height=" 25" background="images/main_02.gif">
                     <p class="main" align="center">
                        <?php
                           if($_SESSION['PERMISSION_04'])
                           {
                              echo "<a class=\"main\" href=\"lookup_reports.php\">REPORTS</a>";
                           } else {
                              echo "<b>REPORTS</b>";
                           }
                        ?>
                     </p>
                  </td>
                  <td width="125" height=" 25" background="images/main_02.gif">
                     <p class="main" align="center">
                        <?php
                           if($_SESSION['LEVEL'])
                           {
                              echo "<a class=\"main\" href=\"lookup_account.php\">USER ACCOUNT</a>";
                           } else {
                              echo "<a class=\"main\" href=\"detail_password.php\">SET PASSWORD</a>";
                           }
                        ?>
                     </p>
                  </td>
                  <td width="125" height=" 25" background="images/main_03.gif">
                     <p class="main" align="center">
                        <a class="main" href="logout.php">LOGOUT</a>
                     </p>
                  </td>
               </tr>
               </table>
            </td>
         </tr>
         </table>
         </center></div>
      </td>
   </tr>
   <tr>
      <td width="100%" background="images/back_02.gif">
         <div align="center"><center>
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <tr>
            <td width="750" background="images/back_04.gif">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <form name="form" method="post">
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <?php
                  if($strError)
                  {
               ?>
               <tr>
                  <td width="750" height=" 20">
                     <p class="form" align="left"><?php echo $strError; ?></p>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <?php
                  }
               ?>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <tr>
                        <td width="200" height="25">
                           <p align="left">No. Dokumen</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="hide" type="text" name="00" size="20" maxlength="20" value="<?php echo $arrData[0]; ?>" readonly>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Pelamar</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input class="hide" type="hidden" name="01" size="20" maxlength="20" value="<?php echo $arrData[1]; ?>" readonly>
                              <input class="hide" type="text"   name="02" size="59" maxlength="50" value="<?php echo $arrData[2]; ?>" readonly>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Tanggal Wawancara</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <select size="1" name="03">
                                 <?php
                                    for($intCount  = 1; $intCount <= 31; $intCount++)
                                    {
                                       echo "<option value=\"". substr("00". $intCount, -2)  ."\" ";
                                       echo $arrData[3]  ==     substr("00". $intCount, -2) ? "selected" : "";
                                       echo ">".                substr("00". $intCount, -2)  ."</option>";
                                    }
                                 ?>
                              </select>
                              <select size="1" name="04">
                                 <?php
                                    for($intCount  = 1; $intCount <= count($arrMonth); $intCount++)
                                    {
                                       echo "<option value=\"". substr("00". $intCount, -2)  ."\" ";
                                       echo $arrData[4]  ==     substr("00". $intCount, -2) ? "selected" : "";
                                       echo ">".                $arrMonth[$intCount]         ."</option>";
                                    }
                                 ?>
                              </select>
                              <select size="1" name="05">
                                 <?php
                                    for($intCount  = 1950; $intCount <= date("Y"); $intCount++)
                                    {
                                       echo "<option value=\"". substr("0000". $intCount, -4)  ."\" ";
                                       echo $arrData[5]  ==     substr("0000". $intCount, -4) ? "selected" : "";
                                       echo ">".                substr("0000". $intCount, -4)  ."</option>";
                                    }
                                 ?>
                              </select>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Pewawancara</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <select class="form" size="1" name="06">
                                 <?php
                                    for($intCount  = 1; $intCount <= count($arrDirected); $intCount++)
                                    {
                                       echo "<option value=\"". $arrDirected[$intCount]  ."\" ";
                                       echo $arrData[6]  ==     $arrDirected[$intCount] ? "selected" : "";
                                       echo ">".                $arrDirected[$intCount]  ."</option>";
                                    }
                                 ?>
                              </select>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Klien</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <select class="form" size="1" name="07">
                                 <?php
                                    for($intCount  = 1; $intCount <= count($arrCompany); $intCount++)
                                    {
                                       echo "<option value=\"". $arrCompany[$intCount]  ."\" ";
                                       echo $arrData[7]  ==     $arrCompany[$intCount] ? "selected" : "";
                                       echo ">".                $arrCompany[$intCount]  ."</option>";
                                    }
                                 ?>
                              </select>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Jabatan</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <select class="form" size="1" name="08">
                                 <?php
                                    for($intCount  = 1; $intCount <= count($arrTitle); $intCount++)
                                    {
                                       echo "<option value=\"". $arrTitle[$intCount]  ."\" ";
                                       echo $arrData[8]  ==     $arrTitle[$intCount] ? "selected" : "";
                                       echo ">".                $arrTitle[$intCount]  ."</option>";
                                    }
                                 ?>
                              </select>
                           </p>
                        </td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <tr>
                        <td width="750" height=" 60" background="images/menu_07.gif">
                           <table cellpadding="0" cellspacing="0" border="0" width="750">
                           <tr>
                              <td width="500" height="30"><p class="menu" align="center">Materi</p></td>
                              <td width="250" height="30"><p class="menu" align="center">Skala Penilaian</p></td>
                           </tr>
                           <tr>
                              <td width="500" height="30"></td>
                              <td width="250" height="30">
                                 <table cellpadding="0" cellspacing="0" border="0" width="250">
                                 <tr>
                                    <td width=" 50">
                                       <p class="menu" align="center"><b>1</b></p>
                                    </td>
                                    <td width=" 50">
                                       <p class="menu" align="center"><b>2</b></p>
                                    </td>
                                    <td width=" 50">
                                       <p class="menu" align="center"><b>3</b></p>
                                    </td>
                                    <td width=" 50">
                                       <p class="menu" align="center"><b>4</b></p>
                                    </td>
                                    <td width=" 50">
                                       <p class="menu" align="center"><b>5</b></p>
                                    </td>
                                 </tr>
                                 </table>
                              </td>
                           </tr>
                           </table>
                        </td>
                     </tr>
                     <tr>
                        <td width="750" height="10"></td>
                     </tr>
                     <tr>
                        <td width="750">
                           <table cellpadding="0" cellspacing="0" border="0" width="750">
                           <tr>
                              <td width="500" height="25">
                                 <p align="left">Motivasi</p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="09" value="1" <?php echo $arrData[9] == 1 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="09" value="2" <?php echo $arrData[9] == 2 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="09" value="3" <?php echo $arrData[9] == 3 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="09" value="4" <?php echo $arrData[9] == 4 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="09" value="5" <?php echo $arrData[9] == 5 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                           </tr>
                           <tr>
                              <td width="500" height="25">
                                 <p align="left">Keputusan / Pemecahan Masalah</p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="10" value="1" <?php echo $arrData[10] == 1 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="10" value="2" <?php echo $arrData[10] == 2 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="10" value="3" <?php echo $arrData[10] == 3 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="10" value="4" <?php echo $arrData[10] == 4 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="10" value="5" <?php echo $arrData[10] == 5 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                           </tr>
                           <tr>
                              <td width="500" height="25">
                                 <p align="left">Ketahanan Terhadap Tekanan</p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="11" value="1" <?php echo $arrData[11] == 1 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="11" value="2" <?php echo $arrData[11] == 2 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="11" value="3" <?php echo $arrData[11] == 3 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="11" value="4" <?php echo $arrData[11] == 4 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="11" value="5" <?php echo $arrData[11] == 5 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                           </tr>
                           <tr>
                              <td width="500" height="25">
                                 <p align="left">Analisa / Pengkajian Masalah</p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="12" value="1" <?php echo $arrData[12] == 1 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="12" value="2" <?php echo $arrData[12] == 2 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="12" value="3" <?php echo $arrData[12] == 3 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="12" value="4" <?php echo $arrData[12] == 4 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="12" value="5" <?php echo $arrData[12] == 5 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                           </tr>
                           <tr>
                              <td width="500" height="25">
                                 <p align="left">Perencanaan / Pengelolaan Kinerja</p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="13" value="1" <?php echo $arrData[13] == 1 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="13" value="2" <?php echo $arrData[13] == 2 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="13" value="3" <?php echo $arrData[13] == 3 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="13" value="4" <?php echo $arrData[13] == 4 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="13" value="5" <?php echo $arrData[13] == 5 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                           </tr>
                           <tr>
                              <td width="500" height="25">
                                 <p align="left">Kemampuan Berkomunikasi</p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="14" value="1" <?php echo $arrData[14] == 1 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="14" value="2" <?php echo $arrData[14] == 2 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="14" value="3" <?php echo $arrData[14] == 3 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="14" value="4" <?php echo $arrData[14] == 4 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="14" value="5" <?php echo $arrData[14] == 5 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                           </tr>
                           <tr>
                              <td width="500" height="25">
                                 <p align="left">Kepemimpinan</p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="15" value="1" <?php echo $arrData[15] == 1 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="15" value="2" <?php echo $arrData[15] == 2 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="15" value="3" <?php echo $arrData[15] == 3 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="15" value="4" <?php echo $arrData[15] == 4 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="15" value="5" <?php echo $arrData[15] == 5 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                           </tr>
                           <tr>
                              <td width="500" height="25">
                                 <p align="left">Inisiatif</p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="16" value="1" <?php echo $arrData[16] == 1 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="16" value="2" <?php echo $arrData[16] == 2 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="16" value="3" <?php echo $arrData[16] == 3 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="16" value="4" <?php echo $arrData[16] == 4 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="16" value="5" <?php echo $arrData[16] == 5 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                           </tr>
                           <tr>
                              <td width="500" height="25">
                                 <p align="left">Pengetahuan Teknis Menjual</p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="17" value="1" <?php echo $arrData[17] == 1 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="17" value="2" <?php echo $arrData[17] == 2 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="17" value="3" <?php echo $arrData[17] == 3 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="17" value="4" <?php echo $arrData[17] == 4 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="17" value="5" <?php echo $arrData[17] == 5 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                           </tr>
                           <tr>
                              <td width="500" height="25">
                                 <p align="left">Tambahan</p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="18" value="1" <?php echo $arrData[18] == 1 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="18" value="2" <?php echo $arrData[18] == 2 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="18" value="3" <?php echo $arrData[18] == 3 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="18" value="4" <?php echo $arrData[18] == 4 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                              <td width=" 50" height="25">
                                 <p align="center"><input type="radio" name="18" value="5" <?php echo $arrData[18] == 5 ? "checked" : ""; ?> onclick="JavaScript:GetValue()"></p>
                              </td>
                           </tr>
                           </table>
                        </td>
                     </tr>
                     <tr>
                        <td width="750" height="10"></td>
                     </tr>
                     <tr>
                        <td width="750" height=" 30" background="images/menu_08.gif">
                           <table cellpadding="0" cellspacing="0" border="0" width="750">
                           <tr>
                              <td width="  5" height="25"></td>
                              <td width="490" height="25">
                                 <p class="head" align="left"><b>Total Nilai</b></p>
                              </td>
                              <td width=" 10" height="25"></td>
                              <td width="240" height="25">
                                 <p class="head" align="right">
                                    <input class="head" type="text" name="19" size="20" maxlength="20" value="<?php echo $arrData[19]; ?>" readonly>
                                 </p>
                              </td>
                              <td width="  5" height="25"></td>
                           </tr>
                           </table>
                        </td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <tr>
                        <td width="200" height="25">
                           <p align="left"><b>Skala Penilaian :</b></p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">(1) Kurang Sekali (2) Kurang (3) Cukup (4) Baik (5) Baik Sekali</p>
                        </td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Tanggal Wawancara di Klien</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <select size="1" name="20">
                                 <?php
                                    for($intCount  = 1; $intCount <= 31; $intCount++)
                                    {
                                       echo "<option value=\"". substr("00". $intCount, -2)  ."\" ";
                                       echo $arrData[20] ==     substr("00". $intCount, -2) ? "selected" : "";
                                       echo ">".                substr("00". $intCount, -2)  ."</option>";
                                    }
                                 ?>
                              </select>
                              <select size="1" name="21">
                                 <?php
                                    for($intCount  = 1; $intCount <= count($arrMonth); $intCount++)
                                    {
                                       echo "<option value=\"". substr("00". $intCount, -2)  ."\" ";
                                       echo $arrData[21] ==     substr("00". $intCount, -2) ? "selected" : "";
                                       echo ">".                $arrMonth[$intCount]         ."</option>";
                                    }
                                 ?>
                              </select>
                              <select size="1" name="22">
                                 <?php
                                    for($intCount  = 1950; $intCount <= date("Y"); $intCount++)
                                    {
                                       echo "<option value=\"". substr("0000". $intCount, -4)  ."\" ";
                                       echo $arrData[22] ==     substr("0000". $intCount, -4) ? "selected" : "";
                                       echo ">".                substr("0000". $intCount, -4)  ."</option>";
                                    }
                                 ?>
                              </select>
                            ��<input type="checkbox" name="23" <?php echo $arrData[23] == 1 ? "checked" : ""; ?>>Atur Jadwal di Klien</input>
                           </p>
                        </td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750">
                     <table cellpadding="0" cellspacing="0" border="0" width="750">
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Catatan Khusus</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <textarea name="24" rows="3" cols="61"><?php echo $arrData[24]; ?></textarea>
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25">
                           <p align="left">Hasil Interview</p>
                        </td>
                        <td width="550" height="25">
                           <p align="left">
                              <input type="radio" name="25" value="RJ" <?php echo $arrData[25] == "RJ" ? "checked" : ""; ?>>Tolak
                              <input type="radio" name="25" value="CS" <?php echo $arrData[25] == "CS" ? "checked" : ""; ?>>Pertimbangkan
                              <input type="radio" name="25" value="AC" <?php echo $arrData[25] == "AC" ? "checked" : ""; ?>>Terima
                           </p>
                        </td>
                     </tr>
                     <tr>
                        <td width="200" height="25"></td>
                        <td width="550" height="25">
                           <p align="left">
                              Total Nilai < 25������: <b>Tolak</b><br>
                              Total Nilai 25 - 32 : <b>Pertimbangkan</b><br>
                              Total Nilai > 32������: <b>Terima</b>
                           </p>
                        </td>
                     </tr>
                     </table>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750">
                     <p align="left">
                        <input type="image" name="26" src="images/button_05.gif" width="90" height="30">
                        <a href="lookup_interview.php?<?php echo $strObject; ?>"><img src="images/button_07.gif" width="90" height="30" border="0"></a>
                     </p>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               </table>
            </td>
         </tr>
         </table>
         </center></div>
      </td>
   </tr>
   <tr>
      <td width="100%" background="images/back_01.gif">
         <div align="center"><center>
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <tr>
            <td width="750" background="images/back_03.gif">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               <tr>
                  <td width="750">
                     <p class="foot" align="right">
                        <a class="foot" href="http://www.exteron.com/">Exteron Corporation</a> � 2011 All rights reserved
                     </p>
                  </td>
               </tr>
               <tr>
                  <td width="750" height=" 20"></td>
               </tr>
               </table>
            </td>
         </tr>
         </table>
         </center></div>
      </td>
   </tr>
   </table>
</body>

</html>