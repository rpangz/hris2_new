<?php ob_start();                     ?>
<?php session_start();                ?>
<?php include "data/condata.php";     ?>
<?php include "modules/function.php"; ?>

<?php
   if(!$_SESSION['LOGIN'])
   {
      header("Location:login.php");
   }
   
   $arrForm[0]         = $_GET['00'];
   $arrForm[1]         = $_GET['01'];
   $arrForm[2]         = $_GET['02'];
   $arrForm[3]         = $_GET['03'];
   $arrForm[4]         = $_GET['04'];
   $arrForm[5]         = $_GET['05'];
   $arrForm[6]         = $_GET['06'];
   $arrForm[7]         = $_GET['07'];
   $arrForm[8]         = $_GET['08'];
   $arrForm[9]         = $_GET['09'];
   $arrForm[10]        = $_GET['10'];
   $arrForm[11]        = $_GET['11'];
   $arrForm[12]        = $_GET['12'];
   $arrForm[13]        = $_GET['13'];
   $arrForm[14]        = $_GET['14'];
   
   switch($arrForm[14])
   {
      case "AL"        : $strFilter  = "WHERE (Ms_Card.Card_Type IN ('RG', 'EM'))";
                         break;
      case "RG"        : $strFilter  = "WHERE (Ms_Card.Card_Type  = 'RG')";
                         break;
      case "EM"        : $strFilter  = "WHERE (Ms_Card.Card_Type  = 'EM')";
                         break;
   }
   
   for($intCount       = 0; $intCount < count($arrForm); $intCount++)
   {
      switch($intCount)
      {
         case 0        : $strFilter .= $arrForm[0]  != "" ? "AND (YEAR(NOW()) - YEAR(Ms_Card.Card_Date) <= '$arrForm[0]')" : "";
                         break;
         case 1        : $strFilter .= $arrForm[1]  != "" ? "AND (Ms_Card.Card_Gender     = '$arrForm[1]')" : "";
                         break;
         case 2        : $strFilter .= $arrForm[2]  != "" ? "AND (Ms_Card.Card_Religion   = '$arrForm[2]')" : "";
                         break;
         case 3        : $strFilter .= $arrForm[3]  != "" ? "AND (Ms_Card.Card_Relation   = '$arrForm[3]')" : "";
                         break;
         case 4        : $strFilter .= $arrForm[4]  != "" ? "AND (Ms_Card.Card_City       = '$arrForm[4]')" : "";
                         break;
         case 5        : $strFilter .= $arrForm[5]  != "" ? "AND (Ms_Card.Card_House      = '$arrForm[5]')" : "";
                         break;
         case 6        : $strFilter .= $arrForm[6]  != "" ? "AND (Ms_Card.Card_Vehicle    = '$arrForm[6]')" : "";
                         break;
         case 7        : $strFilter .= $arrForm[7]  != "" ? "AND (Ms_Card.Card_Interest   = '$arrForm[7]')" : "";
                         break;
         case 8        : $strFilter .= $arrForm[8]  != "" ? "AND (Ms_Card.Card_Advertize  = '$arrForm[8]')" : "";
                         break;
         case 9        : $strFilter .= $arrForm[9]  != "" ? $arrForm[9]  != "SMU" ? "AND (ISNULL(Ms_Card.Card_2nd_College) = 0)" : "AND (ISNULL(Ms_Card.Card_1st_College) = 0)" : "";
                         break;
         case 10       : $strFilter .= $arrForm[10] != "" ? "AND (Ms_Card.Card_2nd_Grade >= '$arrForm[10]')" : "";
                         break;
         case 11       : $strFilter .= $arrForm[11] != "" ? "AND (Ms_Card.Card_Company    = '$arrForm[11]')" : "";
                         break;
         case 12       : $strFilter .= $arrForm[12] != "" ? "AND (Ms_Card.Card_Title      = '$arrForm[12]')" : "";
                         break;
         case 13       : $strFilter .= $arrForm[13] != "" ? "AND (Ms_Card.Card_Newsletter = '$arrForm[13]')" : "";
                         break;
      }
   }
   
   $qrData             = "SELECT Ms_Card.*, Ms_Interview.*, ".
                                "YEAR(NOW()) - YEAR(Ms_Card.Card_Date) AS Card_Age ".
                         "FROM  (Ms_Card LEFT JOIN Ms_Interview ON Ms_Card.Card_Reference = Ms_Interview.Interview_Card) $strFilter ".
                         "ORDER BY Ms_Card.Card_Reference";
   
   $rsData             = mysql_query($qrData);
   
   $intCount           = 0;
   
   while($arrFields    = mysql_fetch_array($rsData))
   {
      $arrData[$intCount][0] = stripslashes($arrFields[0]);
      $arrData[$intCount][1] = stripslashes($arrFields[2]);
      $arrData[$intCount][2] = stripslashes($arrFields[122]);
      $arrData[$intCount][3] = stripslashes($arrFields[12]);
      $arrData[$intCount][4] = stripslashes($arrFields[15]);
      $arrData[$intCount][5] = stripslashes($arrFields[16]);
      $arrData[$intCount][6] = stripslashes($arrFields[34]);
      
      $intCount++;
   }
   
   $intTotal           = 0;
?>

<html>

<head>
   <meta http-equiv="Content-Language" content="en-us">
   <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
   <meta name="Keywords" content="Bursa Kerja, Career, Calon Karyawan, Cari Kerja, HRD, Human Resources, Indonesia, Interview, Jobs, Job Fair, Job Seeker, Karir, Kinerja, Lowongan, Outsources, Outsourcing, Recruitments, Relasi, Relationships, Resources, SDM, Sumber Daya Manusia, Tenaga Kerja, Wawancara">
   <meta name="Description" content="Indonesia's Best Outsourcing">
   <meta name="Author" content="Exteron Corporation">
   <title>..:: PT Jasmine Indonesia ::..</title>
   <link href="style.css" type="text/css" rel="stylesheet">
</head>

<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0">
   <div align="center"><center>
   <table cellpadding="0" cellspacing="0" border="0" width="750">
   <tr>
      <td width="750" height=" 20"></td>
   </tr>
   <tr>
      <td width="750"><p class="head" align="center"><b>JASMINE INDONESIA PT</b></p></td>
   </tr>
   <tr>
      <td width="750">
         <p class="prnt" align="center">
            <?php
               switch($arrForm[14])
               {
                  case "AL" : echo "<b>Daftar Pelamar dan Karyawan (Lihat Semua)</b>";
                              break;
                  case "RG" : echo "<b>Daftar Pelamar dan Karyawan (Hanya Pelamar)</b>";
                              break;
                  case "EM" : echo "<b>Daftar Pelamar dan Karyawan (Hanya Karyawan)</b>";
                              break;
               }
            ?>
         </p>
      </td>
   </tr>
   <tr>
      <td width="750" height=" 50"></td>
   </tr>
   <tr>
      <td width="750" height="  1" background="images/spacer_01.gif""></td>
   </tr>
   <tr>
      <td width="750" height=" 10"></td>
   </tr>
   <tr>
      <td width="750">
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <tr>
            <td width="  5"></td>
            <td width=" 90"><p class="prnt" align="left"><b>No. Dokumen</b></p></td>
            <td width=" 10"></td>
            <td width="190"><p class="prnt" align="left"><b>Nama Lengkap</b></p></td>
            <td width=" 10"></td>
            <td width=" 40"><p class="prnt" align="right"><b>Usia</b></p></td>
            <td width=" 10"></td>
            <td width="140"><p class="prnt" align="left"><b>Kota</b></p></td>
            <td width=" 10"></td>
            <td width=" 90"><p class="prnt" align="left"><b>No. Telp</b></p></td>
            <td width=" 10"></td>
            <td width=" 90"><p class="prnt" align="left"><b>No. Ponsel</b></p></td>
            <td width=" 10"></td>
            <td width=" 40"><p class="prnt" align="right"><b>IPK</b></p></td>
            <td width="  5"></td>
         </tr>
         </table>
      </td>
   </tr>
   <tr>
      <td width="750" height=" 10"></td>
   </tr>
   <tr>
      <td width="750" height="  1" background="images/spacer_01.gif"></td>
   </tr>
   <tr>
      <td width="750" height=" 10"></td>
   </tr>
   <tr>
      <td width="750">
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <?php
            for($intCount  = 0; $intCount < mysql_num_rows($rsData); $intCount++)
            {
         ?>
         <tr>
            <td width="750">
               <table cellpadding="0" cellspacing="0" border="0" width="750">
               <tr>
                  <td width="  5"></td>
                  <td width=" 90">
                     <p class="prnt" align="left"><?php  echo $arrData[$intCount][0]; ?></p>
                  </td>
                  <td width=" 10"></td>
                  <td width="190">
                     <p class="prnt" align="left"><?php  echo $arrData[$intCount][1]; ?></p>
                  </td>
                  <td width=" 10"></td>
                  <td width=" 40">
                     <p class="prnt" align="right"><?php echo $arrData[$intCount][2]; ?></p>
                  </td>
                  <td width=" 10"></td>
                  <td width="140">
                     <p class="prnt" align="left"><?php  echo $arrData[$intCount][3]; ?></p>
                  </td>
                  <td width=" 10"></td>
                  <td width=" 90">
                     <p class="prnt" align="left"><?php  echo $arrData[$intCount][4]; ?></p>
                  </td>
                  <td width=" 10"></td>
                  <td width=" 90">
                     <p class="prnt" align="left"><?php  echo $arrData[$intCount][5]; ?></p>
                  </td>
                  <td width=" 10"></td>
                  <td width=" 40">
                     <p class="prnt" align="right"><?php echo $arrData[$intCount][6]; ?></p>
                  </td>
                  <td width="  5"></td>
               </tr>
               </table>
            </td>
         </tr>
         <?php
               $intTotal++;
            }
         ?>
         </table>
      </td>
   </tr>
   <tr>
      <td width="750" height=" 10"></td>
   </tr>
   <tr>
      <td width="750" height="  1" background="images/spacer_01.gif""></td>
   </tr>
   <tr>
      <td width="750" height=" 10"></td>
   </tr>
   <tr>
      <td width="750">
         <table cellpadding="0" cellspacing="0" border="0" width="750">
         <tr>
            <td width="  5"></td>
            <td width="690"><p class="prnt" align="left"><b>Grand Total</b></p></td>
            <td width=" 10"></td>
            <td width=" 40"><p class="prnt" align="right"><b><?php echo $intTotal; ?></b></p></td>
            <td width="  5"></td>
         </tr>
         </table>
      </td>
   </tr>
   <tr>
      <td width="750" height=" 10"></td>
   </tr>
   <tr>
      <td width="750" height="  1" background="images/spacer_01.gif"></td>
   </tr>
   <tr>
      <td width="750" height=" 20"></td>
   </tr>
   </table>
   </center></div>
</body>

</html>